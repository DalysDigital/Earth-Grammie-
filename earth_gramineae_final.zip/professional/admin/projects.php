<?php require 'header.php'; $pdo=db(); $msg=''; $err='';
try{
 if(isset($_GET['delete'])){ $pdo->prepare('DELETE FROM projects WHERE id=?')->execute([(int)$_GET['delete']]); header('Location: projects.php?deleted=1'); exit; }
 if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $id=(int)($_POST['id']??0); $image=trim((string)($_POST['old_image']??''));
  if(isset($_FILES['image']) && $_FILES['image']['error']!==UPLOAD_ERR_NO_FILE){
   $f=$_FILES['image']; if($f['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Image upload failed (code '.$f['error'].').');
   if($f['size']>8*1024*1024) throw new RuntimeException('Project image must be under 8 MB.');
   $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']); $map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
   if(!isset($map[$mime])) throw new RuntimeException('Use JPG, PNG or WebP for project images.');
   $dir=dirname(__DIR__).'/uploads/projects'; if(!is_dir($dir) && !mkdir($dir,0775,true)) throw new RuntimeException('Cannot create project upload directory.');
   if(!is_writable($dir)) throw new RuntimeException('Project upload directory is not writable.');
   $name='project_'.date('Ymd_His').'_'.bin2hex(random_bytes(5)).'.'.$map[$mime];
   if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name)) throw new RuntimeException('Could not save the uploaded project image.');
   $image='uploads/projects/'.$name;
  }
  $title=trim((string)($_POST['title']??'')); if($title==='') throw new RuntimeException('Project title is required.');
  $data=[$title,trim((string)($_POST['category']??'')),trim((string)($_POST['description']??'')),$image,(int)($_POST['sort_order']??0),isset($_POST['status'])?1:0];
  if($id){$q=$pdo->prepare('UPDATE projects SET title=?,category=?,description=?,image=?,sort_order=?,status=? WHERE id=?');$q->execute([...$data,$id]);}
  else{$q=$pdo->prepare('INSERT INTO projects(title,category,description,image,sort_order,status) VALUES(?,?,?,?,?,?)');$q->execute($data);$id=(int)$pdo->lastInsertId();}
  header('Location: projects.php?saved='.$id); exit;
 }
}catch(Throwable $e){$err=$e->getMessage();}
$edit=null;if(isset($_GET['edit'])){$q=$pdo->prepare('SELECT * FROM projects WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$list=$pdo->query('SELECT * FROM projects ORDER BY sort_order,id')->fetchAll();
if(isset($_GET['saved']))$msg='Project saved successfully. Image and content are now stored.'; if(isset($_GET['deleted']))$msg='Project deleted.';
?>
<h1>Projects</h1>
<?php if($msg):?><div class="notice"><?=h($msg)?></div><?php endif;?><?php if($err):?><div class="error"><?=h($err)?></div><?php endif;?>
<div class="card"><h2><?= $edit?'Edit':'Add' ?> project</h2><p class="muted">Upload an image, save, then use Preview to see how the project will appear.</p>
<form method="post" enctype="multipart/form-data" action="projects.php">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=h($edit['id']??0)?>"><input type="hidden" name="old_image" value="<?=h($edit['image']??'')?>">
<div class="row2"><div><label>Project title</label><input name="title" value="<?=h($edit['title']??'')?>" required></div><div><label>Category</label><input name="category" value="<?=h($edit['category']??'')?>"></div></div>
<label>Description</label><textarea name="description"><?=h($edit['description']??'')?></textarea>
<div class="row2"><div class="filebox"><label>Project image</label><input id="projectImage" type="file" name="image" accept="image/jpeg,image/png,image/webp"><div id="imagePreview" class="media-preview"><?php if(!empty($edit['image'])):?><img src="../<?=h($edit['image'])?>" alt="Current project image"><?php endif;?></div></div><div><label>Display order</label><input type="number" name="sort_order" value="<?=h($edit['sort_order']??0)?>"><label><input type="checkbox" name="status" <?=(!$edit||$edit['status'])?'checked':''?>> Visible on website</label></div></div>
<div class="form-actions"><button class="btn" type="submit">Save Project</button><?php if($edit):?><a class="btn light" href="projects.php">Cancel</a><a class="btn gold" href="project_preview.php?id=<?=$edit['id']?>" target="_blank">Preview</a><?php endif;?></div>
</form></div>
<div class="card"><h2>Portfolio</h2><div class="tablewrap"><table class="table"><tr><th>Image</th><th>Project</th><th>Category</th><th>Status</th><th>Actions</th></tr><?php foreach($list as $p):?><tr><td><?php if($p['image']):?><img src="../<?=h($p['image'])?>" alt="<?=h($p['title'])?>"><?php else:?><span class="muted">No image</span><?php endif;?></td><td><b><?=h($p['title'])?></b><br><span class="muted"><?=h($p['description'])?></span></td><td><?=h($p['category'])?></td><td><?=((int)$p['status']?'Visible':'Hidden')?></td><td class="actions"><a class="btn light" href="?edit=<?=$p['id']?>">Edit</a><a class="btn gold" href="project_preview.php?id=<?=$p['id']?>" target="_blank">Preview</a><a class="btn danger" href="?delete=<?=$p['id']?>" onclick="return confirm('Delete this project?')">Delete</a></td></tr><?php endforeach;?></table></div></div>
<script>document.getElementById('projectImage')?.addEventListener('change',function(){const f=this.files?.[0],p=document.getElementById('imagePreview');if(!f||!p)return;const u=URL.createObjectURL(f);p.innerHTML='<img src="'+u+'" alt="Selected project image">';});</script>
<?php require 'footer.php'; ?>
