<?php
declare(strict_types=1);
session_start();
$local = __DIR__.'/config.local.php';
if (file_exists($local)) {
    $cfg = require $local;
} else {
    $cfg = ['db_host'=>'localhost','db_name'=>'earth_gramineae','db_user'=>'root','db_pass'=>'','base_url'=>''];
}
function db(): PDO {
    global $cfg;
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;
    $dsn="mysql:host=".$cfg['db_host'].";dbname=".$cfg['db_name'].";charset=utf8mb4";
    $pdo=new PDO($dsn,$cfg['db_user'],$cfg['db_pass'],[
      PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES=>false
    ]);
    return $pdo;
}
function settings(PDO $pdo): array {
    $out=[];
    try { foreach($pdo->query("SELECT setting_key,setting_value FROM settings") as $r) $out[$r['setting_key']]=$r['setting_value']; }
    catch(Throwable $e) {}
    return $out;
}
function table_has_column(PDO $pdo,string $table,string $column): bool {
    try { $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?"); $q->execute([$table,$column]); return (bool)$q->fetchColumn(); } catch(Throwable $e){ return false; }
}
function page_data(PDO $pdo,string $slug): array {
    try {
        if(!table_has_column($pdo,'pages','content_json')) return [];
        $s=$pdo->prepare("SELECT content_json,custom_css FROM pages WHERE slug=? LIMIT 1"); $s->execute([$slug]);
        $r=$s->fetch();
        if(!$r) return [];
        $d=json_decode($r['content_json']??'',true) ?: [];
        if(!empty($r['custom_css'])) $d['_custom_css']=$r['custom_css'];
        return $d;
    } catch(Throwable $e){ return []; }
}
function projects(PDO $pdo): array {
    try { return $pdo->query("SELECT * FROM projects WHERE status=1 ORDER BY sort_order,id")->fetchAll(); }
    catch(Throwable $e){ return []; }
}
function csrf_token(): string {
    if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_check(): void {
    if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){ http_response_code(419); exit('Invalid security token');}
}
function admin(): array {
    if(empty($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
    return $_SESSION['admin'];
}
function h($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function amount_words(float $n): string {
    $n=round($n,2); $rupees=(int)floor($n); $paise=(int)round(($n-$rupees)*100);
    $ones=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
    $tens=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    $under=function($x)use(&$under,$ones,$tens){
      if($x<20)return $ones[$x]; if($x<100)return $tens[intdiv($x,10)].($x%10?' '.$ones[$x%10]:'');
      return $ones[intdiv($x,100)].' Hundred'.($x%100?' '.$under($x%100):'');
    };
    if($rupees===0)$w='Zero'; else {
      $parts=[];
      $cr=intdiv($rupees,10000000); $rupees%=10000000; $lk=intdiv($rupees,100000); $rupees%=100000;
      $th=intdiv($rupees,1000); $rupees%=1000;
      if($cr)$parts[]=$under($cr).' Crore'; if($lk)$parts[]=$under($lk).' Lakh'; if($th)$parts[]=$under($th).' Thousand'; if($rupees)$parts[]=$under($rupees);
      $w=implode(' ',$parts);
    }
    if($paise) $w.=" and ".$under($paise)." Paise";
    return "Rupees ".$w." Only";
}
function money($n): string { return '₹'.number_format((float)$n,2); }
