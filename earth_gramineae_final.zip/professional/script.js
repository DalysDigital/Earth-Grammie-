const nav=document.querySelector('.nav'),toggle=document.querySelector('.menu-toggle');
toggle?.addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
const lightbox=document.getElementById('lightbox'),lbImg=document.getElementById('lightboxImg'),lbTitle=document.getElementById('lightboxTitle');
document.querySelectorAll('.gallery-card').forEach(card=>card.addEventListener('click',()=>{lbImg.src=card.querySelector('img').src;lbImg.alt=card.querySelector('img').alt;lbTitle.textContent=card.dataset.title||'';lightbox.classList.add('open');lightbox.setAttribute('aria-hidden','false')}));
function closeLightbox(){lightbox.classList.remove('open');lightbox.setAttribute('aria-hidden','true');lbImg.src=''}
document.querySelector('.lightbox-close').addEventListener('click',closeLightbox);lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeLightbox()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeLightbox()});
const form=document.getElementById('contactForm');
function getMessage(){const name=document.getElementById('name').value.trim();const project=document.getElementById('project').value.trim();const msg=document.getElementById('message').value.trim();return `Hello Earth Gramineae,\n\nMy name is ${name}.\nProject / service: ${project||'Not specified'}\n\n${msg}\n\nI would like to discuss this project with you.`}
form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;window.open('https://wa.me/916033096156?text='+encodeURIComponent(getMessage()),'_blank','noopener')});
document.getElementById('emailBtn').addEventListener('click',()=>{if(!form.reportValidity())return;const name=document.getElementById('name').value.trim();const subject='New project enquiry — Earth Gramineae';window.location.href='mailto:earth.gramineae@gmail.com?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(getMessage())});
document.getElementById('year').textContent=new Date().getFullYear();
