<?php require 'header.php';$pdo=db();$edit=null;$items=[];$msg='';$err='';
try{
if(isset($_GET['delete'])){$pdo->prepare('DELETE FROM invoices WHERE id=?')->execute([(int)$_GET['delete']]);header('Location: invoices.php?deleted=1');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check();$id=(int)($_POST['id']??0);$signature=$_POST['old_signature']??'';if(!empty($_FILES['signature']['name'])){$f=$_FILES['signature'];if($f['error']!==UPLOAD_ERR_OK)throw new RuntimeException('Signature upload failed.');$ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));if(!in_array($ext,['png','jpg','jpeg','webp'],true))throw new RuntimeException('Signature must be PNG, JPG, JPEG or WebP.');$dir=__DIR__.'/../uploads/signatures';if(!is_dir($dir))mkdir($dir,0775,true);$name='signature_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;move_uploaded_file($f['tmp_name'],$dir.'/'.$name);$signature='uploads/signatures/'.$name;}
$des=$_POST['description']??[];$price=$_POST['price']??[];$qty=$_POST['qty']??[];$total=0;foreach($des as $i=>$d)$total+=(float)($price[$i]??0)*(float)($qty[$i]??1);$paid=trim((string)($_POST['paid']??''));$paidValue=$paid===''?0:(float)$paid;
$data=[trim($_POST['serial_no']??''),$_POST['invoice_date']??date('Y-m-d'),trim($_POST['due_date']??'On Receipt'),trim($_POST['customer_name']??''),trim($_POST['customer_address']??''),trim($_POST['customer_phone']??''),trim($_POST['customer_email']??''),trim($_POST['bank_details']??''),$total,$paidValue,trim($_POST['notes']??''),$signature];
if(!$data[0]||!$data[3])throw new RuntimeException('Invoice number and customer name are required.');
if($id){$q=$pdo->prepare('UPDATE invoices SET serial_no=?,invoice_date=?,due_date=?,customer_name=?,customer_address=?,customer_phone=?,customer_email=?,bank_details=?,total=?,paid=?,notes=?,signature_image=? WHERE id=?');$q->execute([...$data,$id]);$pdo->prepare('DELETE FROM invoice_items WHERE invoice_id=?')->execute([$id]);}else{$q=$pdo->prepare('INSERT INTO invoices(serial_no,invoice_date,due_date,customer_name,customer_address,customer_phone,customer_email,bank_details,total,paid,notes,signature_image) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute($data);$id=(int)$pdo->lastInsertId();}
$q=$pdo->prepare('INSERT INTO invoice_items(invoice_id,description,price,qty,amount) VALUES(?,?,?,?,?)');foreach($des as $i=>$d){if(trim($d)===''&&((float)($price[$i]??0))==0)continue;$p=(float)($price[$i]??0);$qv=(float)($qty[$i]??1);$q->execute([$id,$d,$p,$qv,$p*$qv]);}header("Location: invoice_view.php?id=$id");exit;}
}catch(Throwable $e){$err=$e->getMessage();}
if(isset($_GET['deleted']))$msg='Invoice deleted.';if(isset($_GET['edit'])){$q=$pdo->prepare('SELECT * FROM invoices WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();if($edit){$q=$pdo->prepare('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id');$q->execute([$edit['id']]);$items=$q->fetchAll();}}
$list=$pdo->query('SELECT * FROM invoices ORDER BY id DESC')->fetchAll();$items=$items?:[['description'=>'','price'=>0,'qty'=>1]];
?>
<div class="invoice-studio">
  <div class="invoice-toolbar">
    <div>
      <h1>Invoices</h1>
      <p>Simple invoice builder · Save → Preview → Print / Save PDF</p>
    </div>
    <a class="invoice-new-btn" href="invoices.php">+ New Invoice</a>
  </div>
  <?php if($msg):?><div class="notice"><?=h($msg)?></div><?php endif;?>
  <?php if($err):?><div class="error"><?=h($err)?></div><?php endif;?>

  <div class="invoice-editor-card">
    <div class="invoice-card-top">
      <div><span class="studio-kicker">INVOICE STUDIO</span><h2><?= $edit?'Edit Invoice':'New Invoice' ?></h2></div>
      <div class="invoice-tip">Fill the first item. Use <b>+ Add Item</b> for additional rows.</div>
    </div>
    <form method="post" enctype="multipart/form-data" action="invoices.php" id="invoiceForm">
      <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
      <input type="hidden" name="id" value="<?=h($edit['id']??0)?>">
      <input type="hidden" name="old_signature" value="<?=h($edit['signature_image']??'')?>">

      <div class="invoice-form-grid">
        <div><label>Invoice / Serial No.</label><input name="serial_no" value="<?=h($edit['serial_no']??'EG-'.date('Ymd-His'))?>" required></div>
        <div><label>Invoice Date</label><input type="date" name="invoice_date" value="<?=h($edit['invoice_date']??date('Y-m-d'))?>"></div>
        <div><label>Invoice Due</label><input name="due_date" value="<?=h($edit['due_date']??'On Receipt')?>"></div>
        <div><label>Paid Amount <small>(leave blank to hide)</small></label><input type="number" step="0.01" min="0" name="paid" value="<?=h(($edit&&$edit['paid']>0)?$edit['paid']:'')?>"></div>
      </div>

      <div class="invoice-form-grid">
        <div><label>Bill To / Customer Name</label><input name="customer_name" value="<?=h($edit['customer_name']??'')?>" required></div>
        <div><label>Client Phone</label><input name="customer_phone" value="<?=h($edit['customer_phone']??'')?>"></div>
        <div><label>Client Email</label><input type="email" name="customer_email" value="<?=h($edit['customer_email']??'')?>"></div>
        <div><label>Digital Signature</label><input type="file" name="signature" accept="image/png,image/jpeg,image/webp"><small>PNG with transparent background works best.</small></div>
      </div>

      <label>Client Address</label>
      <textarea name="customer_address" placeholder="Use the client name above and add the address here."><?=h($edit['customer_address']??'')?></textarea>

      <label>Payment Method / Bank Details</label>
      <textarea name="bank_details" class="bank-field"><?=h($edit['bank_details']??"Canara Bank\nAccount Holder Name: Denzil Donald Lyngdoh\nAccount Number: 110157964845\nIFSC Code: CNRB0001184")?></textarea>

      <div class="items-heading"><div><span class="studio-kicker">PARTICULARS / SERVICES</span><h3>Invoice Items</h3></div><span id="itemCount">1 row</span></div>
      <div class="invoice-item-head"><span>SL. NO.</span><span>PARTICULAR / SERVICE</span><span>AMOUNT</span><span></span></div>
      <div id="items" class="invoice-items">
      <?php foreach($items as $idx=>$it):?><div class="invoice-item-row">
        <div class="slno"><?=($idx+1)?>.</div>
        <input name="description[]" placeholder="Write particular / service" value="<?=h($it['description'])?>">
        <input type="number" step="0.01" min="0" name="price[]" placeholder="0" value="<?=h($it['price'])?>" class="item-price">
        <input type="number" step="0.01" min="0" name="qty[]" value="<?=h($it['qty']?:1)?>" class="item-qty" aria-label="Quantity">
        <button type="button" class="item-remove" onclick="this.closest('.invoice-item-row').remove();renumberItems();">×</button>
      </div><?php endforeach;?></div>
      <button type="button" class="invoice-add-item" onclick="addItem()">+ Add Item</button>

      <div class="invoice-bottom-grid">
        <div>
          <label>Internal Notes</label>
          <textarea name="notes" placeholder="Optional notes"><?=h($edit['notes']??'')?></textarea>
        </div>
        <div class="invoice-total-card">
          <span>Calculated Total</span>
          <strong id="liveTotal">₹ 0.00</strong>
          <div class="total-hint">Amount in words and balance are generated on the preview.</div>
        </div>
      </div>
      <div class="invoice-actions">
        <button class="invoice-save-btn" type="submit">GENERATE &amp; SAVE INVOICE</button>
        <?php if($edit):?><a class="invoice-secondary-btn" href="invoices.php">New Invoice</a><?php endif;?>
      </div>
    </form>
  </div>

  <div class="invoice-archive-card">
    <div class="items-heading"><div><span class="studio-kicker">ARCHIVE</span><h2>Saved Invoices</h2></div><span><?=count($list)?> records</span></div>
    <div class="invoice-archive">
      <?php foreach($list as $i):?><div class="invoice-archive-row">
        <div><b><?=h($i['serial_no'])?></b><small><?=h($i['customer_name'])?> · <?=h($i['invoice_date'])?></small></div>
        <strong><?=money($i['total'])?></strong>
        <div class="actions"><a class="invoice-open-btn" href="invoice_view.php?id=<?=$i['id']?>">OPEN</a><a class="invoice-edit-btn" href="?edit=<?=$i['id']?>">EDIT</a><a class="invoice-delete-btn" href="?delete=<?=$i['id']?>" onclick="return confirm('Delete invoice?')">×</a></div>
      </div><?php endforeach;?>
    </div>
  </div>
</div>
<script>
function addItem(){const box=document.getElementById('items');const n=box.querySelectorAll('.invoice-item-row').length+1;const d=document.createElement('div');d.className='invoice-item-row';d.innerHTML='<div class="slno">'+n+'.</div><input name="description[]" placeholder="Write particular / service"><input type="number" step="0.01" min="0" name="price[]" placeholder="0" class="item-price"><input type="number" step="0.01" min="0" name="qty[]" value="1" class="item-qty" aria-label="Quantity"><button type="button" class="item-remove" onclick="this.closest(\'.invoice-item-row\').remove();renumberItems();">×</button>';box.appendChild(d);updateTotal();}
function renumberItems(){document.querySelectorAll('.invoice-item-row').forEach((r,i)=>r.querySelector('.slno').textContent=(i+1)+'.');document.getElementById('itemCount').textContent=document.querySelectorAll('.invoice-item-row').length+' rows';updateTotal();}
function updateTotal(){let t=0;document.querySelectorAll('.invoice-item-row').forEach(r=>{let p=parseFloat(r.querySelector('.item-price')?.value||0),q=parseFloat(r.querySelector('.item-qty')?.value||1);t+=p*q});document.getElementById('liveTotal').textContent='₹ '+t.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
document.addEventListener('input',e=>{if(e.target.matches('.item-price,.item-qty'))updateTotal()});document.addEventListener('DOMContentLoaded',renumberItems);
</script>
<?php require 'footer.php'; ?>
