EARTH GRAMINEAE - COMIC BOOK THEME

INSTALL (cPanel File Manager)
1. Back up your current index.php (rename it to index-old.php).
2. Upload the zip to the folder that holds index.php and config.php, then Extract.
3. This adds/replaces only: index.php, comic.css, comic.js, assets/fonts/
4. Hard refresh the page (Ctrl+F5).

NOT TOUCHED: assets/images/, logo, config.php, database, admin, styles.css, script.js.
Keep styles.css on the server: the new page reads the top banner picture path from it
(if it cannot, it uses assets/images/img_24.jpeg).

NOTES
- The new page no longer loads styles.css or script.js.
- Custom CSS saved in your admin (theme / global CSS) still loads. If something looks
  odd, clear old CSS written for the previous design.
- The "primary colour" setting now colours the footer, the mission label and the
  mobile browser bar.
- Fonts (Bangers, Comic Neue - open licences included) are local. No CDN.

TO ROLL BACK: restore your old index.php.
