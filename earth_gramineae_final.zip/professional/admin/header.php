<?php require_once __DIR__.'/../config.php'; require_once __DIR__.'/../migrate.php'; $pdo=db(); eg_migrate($pdo); $me=admin(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#20264a"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icon-192.png"><link rel="icon" href="icon-192.png"><link rel="stylesheet" href="admin.css"><title>Earth Gramineae Admin</title></head><body>
<div class="topbar">
  <a href="dashboard.php" class="adminbrand"><span class="brandmark"><img src="../assets/logo.png" alt="Earth Gramineae"></span><span>Earth Gramineae<br><small>ADMIN</small></span></a>
  <button id="installBtn" class="install" type="button">Install App</button>
  <a href="../index.php" target="_blank" rel="noopener">View Site ↗</a><a href="logout.php">Logout</a>
</div>
<div class="layout"><aside>
<a href="dashboard.php">⌂ <span>Dashboard</span></a><a href="page_studio.php">◈ <span>Page Studio</span></a><a href="projects.php">▦ <span>Projects</span></a><a href="invoices.php">▤ <span>Invoices</span></a><a href="letters.php">✎ <span>Letter Heads</span></a><a href="admins.php">♙ <span>Administrators</span></a><a href="settings.php">⚙ <span>Settings</span></a>
</aside><main>
