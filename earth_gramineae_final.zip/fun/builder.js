/* Earth Gramineae — Bamboo Builder: six levels drawn on canvas. No libraries, no image files. */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var cv = $('#game'), ctx = cv && cv.getContext && cv.getContext('2d');
  if (!ctx || !window.EG) return;
  var EG = window.EG, TAU = Math.PI * 2;

  function seeded(n) { return function () { n = (n * 16807) % 2147483647; return (n - 1) / 2147483646; }; }

  /* ---------------- Drawing kit ---------------- */
  var TAN = ['#7a5a24', '#f0d691', '#c29a4d', '#6a4d1e'];
  var GRN = ['#3d5524', '#b7cc6e', '#6f8c3a', '#2f421b'];
  var DRK = ['#4d3818', '#b8924f', '#85652f', '#3d2c12'];
  function poly(c, pts, fill) {
    c.beginPath(); c.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    c.closePath(); c.fillStyle = fill; c.fill();
  }
  /* one bamboo culm from point to point, with shading and joints */
  function culm(c, x1, y1, x2, y2, w, tone) {
    var t = tone || TAN, dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
    c.save(); c.translate(x1, y1); c.rotate(Math.atan2(dy, dx));
    var g = c.createLinearGradient(0, -w / 2, 0, w / 2);
    g.addColorStop(0, t[0]); g.addColorStop(0.3, t[1]); g.addColorStop(0.65, t[2]); g.addColorStop(1, t[3]);
    c.fillStyle = g; c.fillRect(0, -w / 2, len, w);
    var step = Math.max(22, w * 3.2);
    for (var x = step * 0.7; x < len - 5; x += step) {
      c.fillStyle = t[3]; c.fillRect(x, -w / 2 - 0.8, 2, w + 1.6);
      c.fillStyle = 'rgba(255,240,190,.75)'; c.fillRect(x + 2, -w / 2, 1.2, w);
    }
    c.fillStyle = t[3]; c.fillRect(0, -w / 2, 1.5, w); c.fillRect(len - 1.5, -w / 2, 1.5, w);
    c.restore();
  }
  function lashing(c, x, y, w) {
    c.strokeStyle = '#3b2b18'; c.lineWidth = 2;
    for (var i = -4; i <= 4; i += 3) { c.beginPath(); c.moveTo(x - w / 2, y + i - 2); c.lineTo(x + w / 2, y + i + 2); c.stroke(); }
  }
  function leaf(c, x, y, len, angle, colour) {
    c.save(); c.translate(x, y); c.rotate(angle); c.beginPath(); c.moveTo(0, 0);
    c.quadraticCurveTo(len * 0.35, -len * 0.19, len, 0); c.quadraticCurveTo(len * 0.35, len * 0.19, 0, 0);
    c.fillStyle = colour; c.fill(); c.restore();
  }
  function thatch(c, cx, eave, half, h, topHalf, seed) {
    var top = eave - h, th = topHalf || 6, rnd = seeded(seed || 5);
    function outline() {
      c.beginPath(); c.moveTo(cx - th, top); c.lineTo(cx + th, top);
      c.quadraticCurveTo(cx + th + (half - th) * 0.3, eave - h * 0.28, cx + half, eave);
      var n = Math.round(half / 7);
      for (var i = 1; i <= n; i++) { var x = cx + half - i * 2 * half / n; c.lineTo(x + half / n, eave + 3 + rnd() * 7); c.lineTo(x, eave + rnd() * 3); }
      c.quadraticCurveTo(cx - th - (half - th) * 0.3, eave - h * 0.28, cx - th, top); c.closePath();
    }
    var g = c.createLinearGradient(0, top, 0, eave + 8);
    g.addColorStop(0, '#caa862'); g.addColorStop(0.55, '#9a7637'); g.addColorStop(1, '#5d4420');
    outline(); c.fillStyle = g; c.fill();
    c.save(); outline(); c.clip(); c.lineWidth = 1.1;
    for (var i = 0; i < half * 1.3; i++) {
      var u = rnd() * 2 - 1, v = rnd(), y = top + v * h, spread = th + (half - th) * Math.pow(v, 1.4), x = cx + u * spread;
      c.strokeStyle = rnd() < 0.5 ? 'rgba(244,218,150,.6)' : 'rgba(60,40,12,.45)';
      c.beginPath(); c.moveTo(x, y); c.lineTo(x + u * 13, y + 9 + rnd() * 12); c.stroke();
    }
    [0.38, 0.7].forEach(function (k) {
      c.strokeStyle = 'rgba(45,28,8,.45)'; c.lineWidth = 3;
      c.beginPath(); c.moveTo(cx - half, top + h * k - 5); c.quadraticCurveTo(cx, top + h * k + 12, cx + half, top + h * k - 5); c.stroke();
    });
    c.restore();
    culm(c, cx - th - 4, top, cx + th + 4, top, 8, DRK);
  }
  function lantern(c, x, y, drop) {
    var cy = y + drop + 13;
    c.strokeStyle = '#2d2110'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + drop); c.stroke();
    var glow = c.createRadialGradient(x, cy, 2, x, cy, 46);
    glow.addColorStop(0, 'rgba(255,198,92,.6)'); glow.addColorStop(1, 'rgba(255,198,92,0)');
    c.fillStyle = glow; c.beginPath(); c.arc(x, cy, 46, 0, TAU); c.fill();
    var body = c.createRadialGradient(x - 3, cy - 3, 1, x, cy, 16);
    body.addColorStop(0, '#fff3c4'); body.addColorStop(1, '#dd8b2d');
    c.fillStyle = body; c.beginPath(); c.ellipse(x, cy, 11, 14, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(90,52,10,.7)'; c.lineWidth = 1;
    [-5, 0, 5].forEach(function (o) { c.beginPath(); c.ellipse(x, cy, Math.abs(o) + 1, 14, 0, 0, TAU); c.stroke(); });
    c.fillStyle = '#3b2b18'; c.fillRect(x - 6, cy - 17, 12, 4); c.fillRect(x - 6, cy + 13, 12, 4);
  }
  function plant(c, x, y, s) {
    for (var i = 0; i < 9; i++) leaf(c, x, y - 18 * s, (30 + (i % 3) * 12) * s, -Math.PI + 0.3 + i * 0.32, ['#4f7034', '#75973f', '#92ae4e'][i % 3]);
    poly(c, [[x - 17 * s, y - 22 * s], [x + 17 * s, y - 22 * s], [x + 12 * s, y], [x - 12 * s, y]], '#a65f37');
    c.fillStyle = '#c07a4c'; c.fillRect(x - 19 * s, y - 26 * s, 38 * s, 6 * s);
  }

  /* ---------------- Reusable building steps. Each add() is one visible piece ---------------- */
  function deck(add, x1, x2, y, h) {
    for (var x = x1; x < x2 - 1; x += 46) (function (a, b) {
      add(function (c) { culm(c, a, y + h * 0.28, b, y + h * 0.28, h * 0.56, TAN); culm(c, a, y + h * 0.77, b, y + h * 0.77, h * 0.46, DRK); });
    })(x, Math.min(x2, x + 46.5));
  }
  function post(add, x, y1, y2, w, tone) { add(function (c) { culm(c, x, y1, x, y2, w, tone); lashing(c, x, y2 + 12, w + 2); }); }
  function rail(add, x1, x2, y, h) {
    var n = Math.max(2, Math.round((x2 - x1) / 24));
    add(function (c) {
      for (var i = 1; i < n; i++) culm(c, x1 + i * (x2 - x1) / n, y, x1 + i * (x2 - x1) / n, y - h + 4, 5, TAN);
      culm(c, x1, y - h * 0.3, x2, y - h * 0.3, 5, DRK);
    });
    add(function (c) { culm(c, x1, y - h, x2, y - h, 8, TAN); });
  }
  function lattice(add, x1, x2, y1, y2) {
    add(function (c) {
      c.save(); c.beginPath(); c.rect(x1, y1, x2 - x1, y2 - y1); c.clip();
      var h = y2 - y1;
      for (var x = x1 - h; x < x2; x += 17) { culm(c, x, y2, x + h, y1, 3, DRK); culm(c, x, y1, x + h, y2, 3, TAN); }
      c.restore(); culm(c, x1, y2, x2, y2, 5, TAN);
    });
  }
  function roofSteps(add, cx, eave, half, h, topHalf, seed) {
    add(function (c) { culm(c, cx - half + 14, eave, cx, eave - h + 8, 7, DRK); culm(c, cx + half - 14, eave, cx, eave - h + 8, 7, DRK); });
    add(function (c) { thatch(c, cx, eave, half, h, topHalf, seed); });
  }
  function finial(add, cx, y) {
    add(function (c) {
      culm(c, cx, y, cx, y - 22, 5, DRK); c.fillStyle = '#d9b766'; c.beginPath(); c.arc(cx, y - 26, 7, 0, TAU); c.fill();
      leaf(c, cx, y - 30, 24, -0.6, '#7d9a45'); leaf(c, cx, y - 30, 20, -2.4, '#5f7f38');
    });
  }
  function gazebo(add, cx, half, postH, roofH, base, seed) {
    var floor = base - 16, beam = floor - postH;
    deck(add, cx - half - 18, cx + half + 18, floor, 16);
    [-0.55, 0.55].forEach(function (k) { post(add, cx + half * k, floor, beam, 8, DRK); });
    post(add, cx - half, floor, beam, 14, TAN); post(add, cx + half, floor, beam, 14, TAN);
    rail(add, cx - half, cx - half * 0.32, floor, postH * 0.3);
    rail(add, cx + half * 0.32, cx + half, floor, postH * 0.3);
    lattice(add, cx - half, cx + half, beam + 2, beam + Math.min(30, postH * 0.2));
    add(function (c) { culm(c, cx - half - 22, beam, cx + half + 22, beam, 13, TAN); });
    add(function (c) {
      var d = Math.min(36, half * 0.32), y = beam + Math.min(30, postH * 0.2);
      culm(c, cx - half, y + d, cx - half + d, y, 6, TAN); culm(c, cx + half, y + d, cx + half - d, y, 6, TAN);
    });
    roofSteps(add, cx, beam - 3, half + Math.min(60, half * 0.4), roofH, 0, seed);
    finial(add, cx, beam - 3 - roofH);
  }

  /* ---------------- The six structures (x: -390..390, y: 0 is the ground) ---------------- */
  var LEVELS = [
    { name: 'Garden Gazebo', ask: 'Garden gazebo', goal: 12, speed: 0.29, gap: 1.05, bad: 0.14, wind: 0,
      sky: ['#a9d3d2', '#f3e9c9'], hills: ['#8fb3a2', '#5f8a6c', '#3f6a45'], ground: '#5a7f38', sun: [650, 0.17, '#fff3cb'],
      build: function (add) {
        add(function (c) { deck(function (f) { f(c); }, -70, 70, -6, 8); });
        gazebo(add, 0, 180, 180, 120, 0, 3);
        add(function (c) { lantern(c, -80, -194, 22); }); add(function (c) { lantern(c, 80, -194, 22); });
        add(function (c) { plant(c, -300, 0, 1.2); }); add(function (c) { plant(c, 300, 0, 1.2); });
      } },
    { name: 'Twin Gazebos', ask: 'Twin gazebos with walkway', goal: 16, speed: 0.31, gap: 0.98, bad: 0.16, wind: 0,
      sky: ['#8cc3dc', '#e8efd9'], hills: ['#86aea8', '#557f66', '#35603f'], ground: '#527936', sun: [150, 0.14, '#fffbe4'],
      build: function (add) {
        gazebo(add, -232, 100, 160, 100, 0, 9);
        gazebo(add, 232, 100, 160, 100, 0, 17);
        deck(add, -114, 114, -30, 14);
        [-70, 0, 70].forEach(function (x) { post(add, x, 0, -16, 9, DRK); });
        rail(add, -112, 112, -30, 46);
        add(function (c) {
          c.strokeStyle = '#3b2b18'; c.lineWidth = 2; c.beginPath(); c.moveTo(-132, -180); c.quadraticCurveTo(0, -130, 132, -180); c.stroke();
        });
        [[-66, -163], [0, -155], [66, -163]].forEach(function (p) { add(function (c) { lantern(c, p[0], p[1], 6); }); });
        add(function (c) { plant(c, -60, -30, 0.7); }); add(function (c) { plant(c, 60, -30, 0.7); });
      } },
    { name: 'Tiered Pavilion', ask: 'Multi-level bamboo pavilion', goal: 20, speed: 0.33, gap: 0.92, bad: 0.18, wind: 0,
      sky: ['#e7b98a', '#f8e6bd'], hills: ['#b79a78', '#7d8157', '#55693a'], ground: '#667b34', sun: [640, 0.2, '#ffe0a0'],
      build: function (add) {
        function tier(floor, half, h, posts, seed) {
          for (var i = 0; i < posts; i++) post(add, -half + i * 2 * half / (posts - 1), floor, floor - h, i === 0 || i === posts - 1 ? 12 : 8, TAN);
          rail(add, -half, half, floor, h * 0.34);
          lattice(add, -half, half, floor - h + 2, floor - h + 18);
          add(function (c) { culm(c, -half - 16, floor - h, half + 16, floor - h, 11, TAN); });
        }
        deck(add, -240, 240, -16, 16);
        tier(-16, 200, 90, 6, 1);
        roofSteps(add, 0, -108, 262, 34, 160, 21);
        deck(add, -158, 158, -152, 11);
        tier(-152, 135, 70, 5, 2);
        roofSteps(add, 0, -224, 188, 30, 100, 31);
        deck(add, -98, 98, -264, 11);
        tier(-264, 78, 56, 4, 3);
        roofSteps(add, 0, -322, 130, 62, 0, 41);
        finial(add, 0, -384);
        add(function (c) { culm(c, 236, 0, 168, -142, 6, DRK); culm(c, 268, 0, 200, -142, 6, DRK); });
        add(function (c) { for (var i = 1; i < 8; i++) culm(c, 236 - i * 8.5, -i * 17.7, 268 - i * 8.5, -i * 17.7, 5, TAN); });
        [-232, -150, 150].forEach(function (x, i) { add(function (c) { lantern(c, x, i ? -207 : -104, 12); }); });
        add(function (c) { plant(c, -320, 0, 1.15); }); add(function (c) { plant(c, 330, 0, 1); });
      } },
    { name: 'Welcome Gate', ask: 'Bamboo entrance gate', goal: 20, speed: 0.35, gap: 0.88, bad: 0.2, wind: 28,
      sky: ['#6f6a9c', '#f1b98c'], hills: ['#76678a', '#4d5a55', '#2f4a34'], ground: '#42602f', sun: [140, 0.34, '#ffd59a'],
      build: function (add) {
        add(function (c) { for (var i = 0; i < 6; i++) { c.fillStyle = i % 2 ? '#b8ab92' : '#cabfa8'; c.beginPath(); c.ellipse((i % 2 ? 40 : -35), -4 + i * 8, 40 + i * 7, 5 + i, 0, 0, TAU); c.fill(); } });
        [-1, 1].forEach(function (s) {
          add(function (c) { c.fillStyle = '#7d7466'; c.fillRect(s * 212 - 34, -18, 68, 18); c.fillStyle = '#968c7b'; c.fillRect(s * 212 - 34, -18, 68, 5); });
          [-19, 19, 0].forEach(function (o) { post(add, s * 212 + o, -16, -292, o ? 13 : 17, o ? TAN : GRN); });
          add(function (c) { [-70, -145, -222].forEach(function (y) { lashing(c, s * 212, y, 56); }); });
        });
        add(function (c) { culm(c, -276, -222, 276, -222, 15, TAN); });
        for (var i = 0; i < 12; i++) (function (k) {
          add(function (c) {
            function pt(u) { var a = Math.PI * (1 - u); return [Math.cos(a) * 190, -128 - Math.sin(a) * 86]; }
            var a = pt(k / 12), b = pt((k + 1) / 12); culm(c, a[0], a[1], b[0], b[1], 10, GRN);
          });
        })(i);
        add(function (c) { culm(c, -290, -272, 290, -272, 15, TAN); });
        for (var x = -170; x <= 170; x += 340 / 8) if (Math.abs(x) > 95) post(add, x, -224, -270, 7, DRK);
        add(function (c) {
          c.fillStyle = '#3a2a14'; c.fillRect(-100, -268, 200, 42); c.strokeStyle = '#d9b766'; c.lineWidth = 3; c.strokeRect(-95, -263, 190, 32);
          c.fillStyle = '#f4e2b0'; c.font = '600 21px Fraunces, Georgia, serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('WELCOME', 0, -246);
        });
        roofSteps(add, 0, -282, 330, 74, 120, 51);
        finial(add, -112, -354); finial(add, 112, -354);
        [-150, 150].forEach(function (x) { add(function (c) { lantern(c, x, -216, 44); }); });
        [-1, 1].forEach(function (s) {
          for (var i = 0; i < 6; i++) (function (x, h) { post(add, x, 0, -h, 9, TAN); })(s * (262 + i * 24), 92 - i * 5);
          add(function (c) { culm(c, s * 232, -62, s * 390, -46, 7, DRK); culm(c, s * 232, -30, s * 390, -22, 7, DRK); });
          add(function (c) { plant(c, s * 160, 0, 0.95); });
        });
      } },
    { name: 'Moon Bridge', ask: 'Bamboo garden bridge', goal: 22, speed: 0.37, gap: 0.84, bad: 0.21, wind: 48,
      sky: ['#9bb8bc', '#e3e7dc'], hills: ['#93a9a6', '#68887b', '#42664f'], ground: '#4d6f43', sun: [620, 0.15, '#f4f7ec'], water: true,
      build: function (add) {
        function dk(x) { return -26 - 150 * (1 - (x / 340) * (x / 340)); }
        function under(x) { return -4 - 142 * (1 - (x / 270) * (x / 270)); }
        var i;
        [-1, 1].forEach(function (s) { add(function (c) { c.fillStyle = '#7a7568'; c.beginPath(); c.ellipse(s * 296, -2, 74, 24, 0, Math.PI, TAU); c.fill(); }); });
        for (i = 0; i < 14; i++) (function (a, b) { add(function (c) { culm(c, a, under(a), b, under(b), 16, GRN); }); })(-270 + i * 540 / 14, -270 + (i + 1) * 540 / 14);
        for (i = -4; i <= 4; i++) (function (x) { post(add, x * 52, under(x * 52), dk(x * 52), 8, DRK); })(i);
        for (i = 0; i < 16; i++) (function (a, b) { add(function (c) { culm(c, a, dk(a), b, dk(b), 17, TAN); }); })(-340 + i * 42.5, -340 + (i + 1) * 42.5);
        for (i = -6; i <= 6; i++) (function (x) { post(add, x, dk(x), dk(x) - 58, 8, TAN); })(i * 54);
        for (i = 0; i < 12; i++) (function (a, b) { add(function (c) { culm(c, a, dk(a) - 56, b, dk(b) - 56, 9, TAN); culm(c, a, dk(a) - 28, b, dk(b) - 28, 5, DRK); }); })(-324 + i * 54, -324 + (i + 1) * 54);
        post(add, -78, dk(-78), -290, 11, GRN); post(add, 78, dk(78), -290, 11, GRN);
        add(function (c) { culm(c, -104, -290, 104, -290, 11, TAN); });
        roofSteps(add, 0, -293, 136, 62, 0, 61);
        finial(add, 0, -355);
        add(function (c) { lantern(c, -52, -285, 12); }); add(function (c) { lantern(c, 52, -285, 12); });
        add(function (c) { lantern(c, -324, dk(-324) - 118, 20); culm(c, -324, dk(-324), -324, dk(-324) - 118, 7, DRK); });
        add(function (c) { lantern(c, 324, dk(324) - 118, 20); culm(c, 324, dk(324), 324, dk(324) - 118, 7, DRK); });
        [-370, -250, 262, 372].forEach(function (x) { add(function (c) { plant(c, x, 2, 0.85); }); });
      } },
    { name: 'Eco Retreat', ask: 'Eco retreat / eco-living space', goal: 28, speed: 0.39, gap: 0.8, bad: 0.22, wind: 55,
      sky: ['#0e1d33', '#3d5566'], hills: ['#2b4254', '#1d3236', '#142721'], ground: '#1d3a26', sun: [660, 0.13, '#eef3ff'], night: true,
      build: function (add) {
        var i;
        [-352, -292, -232, -172].forEach(function (x) { post(add, x, 0, -86, 11, DRK); });
        add(function (c) { culm(c, -352, -4, -292, -80, 5, TAN); culm(c, -232, -80, -172, -4, 5, TAN); });
        deck(add, -380, -146, -100, 14);
        for (i = 0; i < 5; i++) (function (x) {
          add(function (c) {
            c.fillStyle = '#9d7c42'; c.fillRect(x, -192, 40, 92); c.strokeStyle = 'rgba(55,38,12,.55)'; c.lineWidth = 2;
            c.save(); c.beginPath(); c.rect(x, -192, 40, 92); c.clip();
            for (var k = -90; k < 130; k += 11) { c.beginPath(); c.moveTo(x + k, -192); c.lineTo(x + k + 92, -100); c.stroke(); c.beginPath(); c.moveTo(x + k + 92, -192); c.lineTo(x + k, -100); c.stroke(); }
            c.restore(); culm(c, x, -100, x, -192, 7, TAN); culm(c, x + 40, -100, x + 40, -192, 7, TAN);
          });
        })(-362 + i * 40);
        add(function (c) { c.fillStyle = '#ffd98a'; c.fillRect(-346, -170, 40, 36); culm(c, -346, -152, -306, -152, 3, DRK); culm(c, -326, -170, -326, -134, 3, DRK); });
        add(function (c) { c.fillStyle = '#4a3417'; c.fillRect(-236, -166, 34, 66); c.fillStyle = '#ffd98a'; c.fillRect(-230, -158, 22, 16); });
        add(function (c) { culm(c, -378, -192, -146, -192, 10, TAN); });
        roofSteps(add, -262, -195, 128, 82, 28, 71);
        [-62, 62].forEach(function (x) { post(add, x + (x < 0 ? -22 : 22), 0, -222, 13, GRN); post(add, x * 0.55, 0, -222, 8, DRK); });
        [0, 1].forEach(function (k) { add(function (c) { var y = -k * 104; culm(c, -80 + k * 5, y - 6, 80 - k * 5, y - 100, 6, TAN); culm(c, 80 - k * 5, y - 6, -80 + k * 5, y - 100, 6, TAN); }); });
        add(function (c) { culm(c, -84, -108, 84, -108, 9, TAN); });
        deck(add, -102, 102, -236, 14);
        post(add, -78, -236, -298, 9, TAN); post(add, 78, -236, -298, 9, TAN);
        rail(add, -78, 78, -236, 30);
        add(function (c) { culm(c, -100, -298, 100, -298, 10, TAN); });
        roofSteps(add, 0, -301, 128, 62, 0, 81);
        finial(add, 0, -363);
        deck(add, -146, -80, -100, 12); rail(add, -144, -82, -100, 34);
        deck(add, 82, 176, -42, 12); rail(add, 84, 174, -42, 32);
        gazebo(add, 262, 86, 112, 74, -26, 91);
        post(add, 205, 0, -26, 10, DRK); post(add, 320, 0, -26, 10, DRK);
        [[-148, -190], [96, -294], [-96, -294], [262, -150]].forEach(function (p) { add(function (c) { lantern(c, p[0], p[1], 14); }); });
        add(function (c) { plant(c, -122, 0, 0.9); }); add(function (c) { plant(c, 140, 0, 0.8); }); add(function (c) { plant(c, 372, 0, 0.7); });
      } }
  ];
  LEVELS.forEach(function (L) { L.parts = []; L.build(function (fn) { L.parts.push(fn); }); });

  /* ---------------- Scenery ---------------- */
  function scenery(c, L, W, H, gy) {
    var rnd = seeded(L.goal * 13), g = c.createLinearGradient(0, 0, 0, gy), i;
    g.addColorStop(0, L.sky[0]); g.addColorStop(1, L.sky[1]); c.fillStyle = g; c.fillRect(0, 0, W, H);
    if (L.night) for (i = 0; i < 90; i++) { c.fillStyle = 'rgba(255,255,255,' + (0.2 + rnd() * 0.7) + ')'; c.fillRect(rnd() * W, rnd() * gy * 0.7, 1.6, 1.6); }
    var sx = L.sun[0], sy = gy * L.sun[1] + 10, halo = c.createRadialGradient(sx, sy, 8, sx, sy, 130);
    halo.addColorStop(0, L.sun[2]); halo.addColorStop(0.2, 'rgba(255,240,200,.35)'); halo.addColorStop(1, 'rgba(255,240,200,0)');
    c.fillStyle = halo; c.beginPath(); c.arc(sx, sy, 130, 0, TAU); c.fill();
    c.fillStyle = L.sun[2]; c.beginPath(); c.arc(sx, sy, 28, 0, TAU); c.fill();
    L.hills.forEach(function (col, n) {
      var base = gy - 190 + n * 68;
      c.beginPath(); c.moveTo(0, H); c.lineTo(0, base);
      for (var x = 0; x < W; x += 160) c.quadraticCurveTo(x + 80, base - 70 + rnd() * 90, x + 160, base - 18 + rnd() * 36);
      c.lineTo(W, H); c.closePath(); c.fillStyle = col; c.fill();
      if (n < 2) { var m = c.createLinearGradient(0, base - 10, 0, base + 70); m.addColorStop(0, 'rgba(255,255,255,0)'); m.addColorStop(1, 'rgba(255,255,255,' + (L.night ? 0.08 : 0.24) + ')'); c.fillStyle = m; c.fillRect(0, base - 10, W, 80); }
    });
    /* bamboo groves framing both sides */
    [0, 1].forEach(function (side) {
      for (var k = 0; k < 6; k++) {
        var x = side ? W - 6 - rnd() * 80 : 6 + rnd() * 80, top = gy - (180 + rnd() * (gy * 0.65)), lean = (rnd() - 0.5) * 36;
        culm(c, x, gy + 6, x + lean, top, 5 + rnd() * 6, L.night ? ['#12261a', '#2f4d31', '#1d3623', '#0c1a11'] : GRN);
        for (var j = 0; j < 16; j++) {
          var v = rnd() * 0.55, px = x + lean * (1 - v), py = top + (gy - top) * v;
          leaf(c, px, py, 20 + rnd() * 24, (rnd() < 0.5 ? 0.5 : 2.6) + (rnd() - 0.5), L.night ? '#254330' : ['#4f7034', '#6f903c', '#8ca94b'][j % 3]);
        }
      }
    });
    c.fillStyle = L.ground; c.fillRect(0, gy, W, H - gy);
    var shade = c.createLinearGradient(0, gy, 0, H); shade.addColorStop(0, 'rgba(255,255,220,.14)'); shade.addColorStop(1, 'rgba(0,0,0,.35)');
    c.fillStyle = shade; c.fillRect(0, gy, W, H - gy);
    if (L.water) {
      var w = c.createLinearGradient(0, gy - 4, 0, H); w.addColorStop(0, '#9cc3c4'); w.addColorStop(1, '#3f6f78');
      c.fillStyle = w; c.beginPath(); c.ellipse(W / 2, gy + 34, 285, 44, 0, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1.5;
      for (i = 0; i < 22; i++) { var rx = W / 2 - 230 + rnd() * 440, ry = gy + 8 + rnd() * 56; c.beginPath(); c.moveTo(rx, ry); c.lineTo(rx + 14 + rnd() * 24, ry); c.stroke(); }
    }
    for (i = 0; i < 130; i++) { var gx = rnd() * W, yy = gy + rnd() * (H - gy); if (L.water && Math.abs(gx - W / 2) < 290 && yy < gy + 76) continue; leaf(c, gx, yy, 5 + rnd() * 11, -1.57 + (rnd() - 0.5) * 1.3, 'rgba(190,215,120,.45)'); }
  }
  function paintParts(c, L, W, gy, from, to) {
    c.save(); c.translate(W / 2, gy);
    for (var i = from; i < to; i++) { c.save(); L.parts[i](c); c.restore(); }
    c.restore();
  }

  /* ---------------- State ---------------- */
  var W = 800, H = 500, GY = 418, level = 0, state = 'ready', score = 0, lives = 3, missed = 0, drops = [], flies = [];
  var bx = 400, dir = 0, timer = 0, last = 0, raf = 0, lastX = 400, shown = 0, settled = 0, anim = [], ambient = 0;
  var bgC = document.createElement('canvas'), builtC = document.createElement('canvas'), ghostC = document.createElement('canvas');
  var stars = (EG.store.get('stars') || '').split(',').map(Number);
  while (stars.length < LEVELS.length) stars.push(0);
  stars = stars.slice(0, LEVELS.length).map(function (n) { return n > 0 && n <= 3 ? n : 0; });
  function unlocked(i) { return i === 0 || stars[i - 1] > 0 || stars[i] > 0; }

  function layer(canvas) {
    canvas.width = cv.width; canvas.height = cv.height;
    var c = canvas.getContext('2d'); c.setTransform(cv.width / W, 0, 0, cv.height / H, 0, 0); return c;
  }
  function rebuild() {
    if (!cv.width) return;
    var L = LEVELS[level];
    scenery(layer(bgC), L, W, H, GY);
    var gc = layer(ghostC); paintParts(gc, L, W, GY, 0, L.parts.length);
    gc.globalCompositeOperation = 'source-in'; gc.fillStyle = L.night ? '#9fc3e6' : '#fffdf2'; gc.fillRect(0, 0, W, H); gc.globalCompositeOperation = 'source-over';
    paintParts(layer(builtC), L, W, GY, 0, settled);
  }
  function size() {
    var r = cv.getBoundingClientRect(); if (!r.width || !r.height) return;
    var dpr = Math.min(2, window.devicePixelRatio || 1), ratio = bx / W, oldH = H;
    cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
    H = Math.max(500, Math.round(W * r.height / r.width)); GY = H - 82; bx = ratio * W;
    drops.forEach(function (d) { d.y *= H / oldH; });
    ctx.setTransform(cv.width / W, 0, 0, cv.height / H, 0, 0);
    rebuild(); draw();
  }

  /* reveal pieces in step with the score */
  function place(instant) {
    var L = LEVELS[level], target = Math.floor(Math.min(score, L.goal) / L.goal * L.parts.length + 0.0001);
    if (instant) {
      shown = settled = target; anim = []; paintParts(layer(builtC), L, W, GY, 0, settled); return;
    }
    for (var i = shown; i < target; i++) anim.push({ i: i, t: -(i - shown) * 0.09 });
    shown = target;
  }
  function settle(dt) {
    anim.forEach(function (a) { a.t += dt * (EG.calm ? 99 : 2.4); });
    while (anim.length && anim[0].t >= 1) {
      var c = builtC.getContext('2d'); paintParts(c, LEVELS[level], W, GY, anim[0].i, anim[0].i + 1); settled = anim[0].i + 1; anim.shift();
    }
  }

  function drawDrop(d) {
    ctx.save(); ctx.translate(d.x, d.y);
    if (d.type === 'pole') { ctx.rotate(d.a); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 8; culm(ctx, -40, -7, 40, -7, 12, TAN); culm(ctx, -40, 7, 40, 7, 12, GRN); lashing(ctx, 0, 0, 12); }
    else if (d.type === 'gold') {
      var gl = ctx.createRadialGradient(0, 0, 4, 0, 0, 50); gl.addColorStop(0, 'rgba(255,224,130,.95)'); gl.addColorStop(1, 'rgba(255,224,130,0)');
      ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(0, 0, 50, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0, -34); ctx.quadraticCurveTo(24, -4, 15, 26); ctx.lineTo(-15, 26); ctx.quadraticCurveTo(-24, -4, 0, -34); ctx.fillStyle = '#e8bd45'; ctx.fill();
      ctx.strokeStyle = '#8a641c'; ctx.lineWidth = 2; ctx.stroke(); ctx.beginPath(); ctx.moveTo(-17, 4); ctx.quadraticCurveTo(0, 8, 11, 24); ctx.moveTo(16, -4); ctx.quadraticCurveTo(0, 0, -6, 16); ctx.stroke();
    } else if (d.type === 'life') {
      var lg = ctx.createRadialGradient(0, 0, 4, 0, 0, 44); lg.addColorStop(0, 'rgba(190,255,150,.9)'); lg.addColorStop(1, 'rgba(190,255,150,0)');
      ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(0, 0, 44, 0, TAU); ctx.fill(); leaf(ctx, -28, 12, 62, -0.45, '#4f8a34');
      ctx.fillStyle = '#fff'; ctx.font = '700 28px Manrope, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('♥', 0, 0);
    } else {
      ctx.rotate(Math.sin(d.a) * 0.25);
      var sack = ctx.createLinearGradient(-30, 0, 30, 0); sack.addColorStop(0, '#6f7176'); sack.addColorStop(0.4, '#c4c5c8'); sack.addColorStop(1, '#77797e');
      ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 9;
      poly(ctx, [[-27, -32], [27, -32], [32, -18], [28, 4], [32, 28], [24, 33], [-24, 33], [-32, 28], [-28, 4], [-32, -18]], sack);
      ctx.shadowBlur = 0; ctx.fillStyle = '#a3402b'; ctx.fillRect(-29, -11, 58, 23);
      ctx.fillStyle = '#fff'; ctx.font = '700 11px Manrope, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('CEMENT', 0, 1);
    }
    ctx.restore();
  }
  function basket() {
    var y = H - 54, w = ctx.createLinearGradient(bx - 68, 0, bx + 68, 0);
    ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(bx, H - 8, 70, 7, 0, 0, TAU); ctx.fill();
    w.addColorStop(0, '#6c4d1e'); w.addColorStop(0.4, '#d6ad5e'); w.addColorStop(1, '#73531f');
    poly(ctx, [[bx - 68, y], [bx + 68, y], [bx + 46, y + 46], [bx - 46, y + 46]], w);
    ctx.save(); ctx.beginPath(); ctx.moveTo(bx - 68, y); ctx.lineTo(bx + 68, y); ctx.lineTo(bx + 46, y + 46); ctx.lineTo(bx - 46, y + 46); ctx.clip();
    ctx.strokeStyle = 'rgba(65,42,10,.7)'; ctx.lineWidth = 2;
    for (var k = -90; k < 100; k += 14) { ctx.beginPath(); ctx.moveTo(bx + k, y); ctx.lineTo(bx + k + 30, y + 46); ctx.moveTo(bx + k, y); ctx.lineTo(bx + k - 30, y + 46); ctx.stroke(); }
    ctx.restore(); culm(ctx, bx - 76, y, bx + 76, y, 13, TAN); culm(ctx, bx - 47, y + 45, bx + 47, y + 45, 7, DRK);
  }
  function draw() {
    if (!cv.width) return;
    var L = LEVELS[level];
    ctx.drawImage(bgC, 0, 0, W, H);
    if (state !== 'won') { ctx.globalAlpha = state === 'ready' ? 0.42 : 0.26; ctx.drawImage(ghostC, 0, 0, W, H); ctx.globalAlpha = 1; }
    ctx.drawImage(builtC, 0, 0, W, H);
    anim.forEach(function (a) {
      if (a.t < 0) return;
      var k = 1 - Math.pow(1 - Math.min(1, a.t), 3);
      ctx.save(); ctx.globalAlpha = k; ctx.translate(0, -70 * (1 - k)); paintParts(ctx, L, W, GY, a.i, a.i + 1); ctx.restore();
    });
    if (L.night || state === 'won') flies.forEach(function (f) {
      var a = 0.35 + 0.65 * Math.abs(Math.sin(f.p));
      if (L.night) { ctx.fillStyle = 'rgba(244,255,150,' + a + ')'; ctx.beginPath(); ctx.arc(f.x + Math.sin(f.p * 0.7) * 24, f.y + Math.cos(f.p * 0.5) * 14, 2.4, 0, TAU); ctx.fill(); }
      else leaf(ctx, (f.x + f.p * 24) % (W + 40) - 20, (f.y + f.p * 38) % H, 17, f.p, f.x % 2 > 1 ? '#c9a45c' : '#7d9a45');
    });
    drops.forEach(drawDrop);
    if (state !== 'won') basket();
  }

  /* ---------------- Interface ---------------- */
  var screen = $('#gScreen'), startBtn = $('#gStart'), againBtn = $('#gAgain'), askBtn = $('#gAsk'), pauseBtn = $('#gPause'), list = $('#levels');
  var buttons = LEVELS.map(function (L, i) {
    var li = document.createElement('li'), b = document.createElement('button');
    b.type = 'button'; b.className = 'level';
    b.innerHTML = '<canvas width="360" height="240" aria-hidden="true"></canvas><span></span><b></b><small></small>';
    b.querySelector('span').textContent = 'Level ' + (i + 1); b.querySelector('b').textContent = L.name;
    var c = b.querySelector('canvas').getContext('2d'); c.setTransform(0.45, 0, 0, 0.45, 0, 0);
    scenery(c, L, 800, 534, 480); paintParts(c, L, 800, 480, 0, L.parts.length);
    b.addEventListener('click', function () { select(i); EG.tone(500, 0.1); });
    li.appendChild(b); list.appendChild(li); return b;
  });
  function paintLevels() {
    buttons.forEach(function (b, i) {
      b.disabled = !unlocked(i);
      b.setAttribute('aria-current', i === level);
      b.querySelector('small').textContent = stars[i] ? '★★★'.slice(0, stars[i]) + '☆☆☆'.slice(0, 3 - stars[i]) : unlocked(i) ? 'Ready to build' : 'Locked';
    });
    var item = buttons[level].parentNode;
    if (list.scrollWidth > list.clientWidth) list.scrollLeft = item.offsetLeft - buttons[0].parentNode.offsetLeft;
    $('#gTotal').textContent = stars.filter(Boolean).length + ' of ' + LEVELS.length + ' structures built';
  }
  function hud() {
    var L = LEVELS[level], n = Math.min(score, L.goal);
    $('#gLevel').textContent = 'Level ' + (level + 1); $('#gName').textContent = L.name;
    $('#gScore').textContent = n; $('#gGoal').textContent = L.goal;
    $('#gBar').style.width = n / L.goal * 100 + '%';
    $('#gLives').textContent = '♥♥♥'.slice(0, lives) + '♡♡♡'.slice(0, 3 - lives);
  }
  function overlay(o) {
    screen.className = 'game-screen' + (o.won ? ' won' : '');
    $('.game').classList.toggle('done', !!o.won);
    $('#gTitle').textContent = o.title; $('#gText').textContent = o.text;
    $('#gStars').hidden = !o.stars; $('#gStars').textContent = o.stars ? '★★★'.slice(0, o.stars) + '☆☆☆'.slice(0, 3 - o.stars) : '';
    startBtn.textContent = o.go; startBtn.hidden = !o.go; againBtn.hidden = !o.again; askBtn.hidden = !o.ask; screen.hidden = false;
  }
  function reset() { score = 0; lives = 3; missed = 0; drops = []; shown = settled = 0; anim = []; timer = 0.2; bx = lastX = W / 2; dir = 0; }
  function select(i) {
    if (!unlocked(i)) return;
    stop(); level = i; state = 'ready'; reset(); pauseBtn.disabled = true; hud(); paintLevels(); rebuild(); draw();
    var L = LEVELS[i];
    overlay({ title: L.name, text: 'Catch ' + L.goal + ' poles to finish this structure.' + (L.wind ? ' Watch out for the wind.' : ''), go: 'Start building' });
  }
  function stop() { cancelAnimationFrame(raf); cancelAnimationFrame(ambient); dir = 0; cv.classList.remove('live'); document.body.classList.remove('playing'); }
  function run() {
    stop(); state = 'play'; screen.hidden = true; $('.game').classList.remove('done'); document.body.classList.add('playing'); pauseBtn.disabled = false; cv.classList.add('live');
    cv.focus({ preventScroll: true }); last = performance.now(); raf = requestAnimationFrame(loop);
  }
  function restart() { stop(); reset(); hud(); place(true); run(); }
  function pause() {
    if (state !== 'play') return;
    state = 'paused'; stop(); pauseBtn.disabled = true; overlay({ title: 'Paused', text: 'Your structure is waiting.', go: 'Resume', again: true });
  }
  function newFlies() { flies = []; for (var i = 0; i < 28; i++) flies.push({ x: Math.random() * W, y: H * 0.15 + Math.random() * H * 0.7, p: Math.random() * 6 }); }
  /* gentle motion after a win: finishes the last pieces, then fireflies or leaves */
  function celebrate() {
    var prev = performance.now(), until = prev + (EG.calm ? 100 : 12000);
    function step(now) {
      var dt = Math.min(0.05, (now - prev) / 1000); prev = now; settle(dt);
      flies.forEach(function (f) { f.p += dt * 1.5; }); draw();
      if (now < until || anim.length) ambient = requestAnimationFrame(step);
    }
    ambient = requestAnimationFrame(step);
  }
  function end(win) {
    var L = LEVELS[level];
    stop(); pauseBtn.disabled = true; drops = [];
    if (win) {
      state = 'won'; stars[level] = Math.max(stars[level], lives); EG.store.set('stars', stars.join(',')); paintLevels(); newFlies(); celebrate();
      var finalLevel = level === LEVELS.length - 1;
      overlay({ won: true, stars: lives, title: finalLevel ? 'Master builder!' : L.name + ' complete',
        text: finalLevel ? 'You have built the complete eco retreat. Imagine it in your own landscape.' : 'Beautifully built. A new structure is unlocked.',
        go: finalLevel ? '' : 'Next level', again: true, ask: true });
      [523, 659, 784, 1047].forEach(function (f, i) { EG.tone(f, 0.22, 'triangle', i * 0.12); });
      var r = cv.getBoundingClientRect(); EG.burst(r.left + r.width / 2, r.top + r.height / 3, 28);
      setTimeout(function () { if (state === 'won') screen.scrollIntoView({ block: 'nearest', behavior: EG.calm ? 'auto' : 'smooth' }); }, 1400);
    } else {
      state = 'lost'; draw();
      overlay({ title: 'So close', text: 'You placed ' + score + ' of ' + L.goal + ' poles. Give it another go.', go: 'Try again', ask: false });
    }
  }
  var notes = [];
  function note(x, y, text, colour) { notes.push({ x: x, y: y, text: text, c: colour, t: 1 }); }
  function loseLife(x, why) {
    lives--; hud(); EG.tone(150, 0.3, 'sawtooth'); note(x, H - 100, why, '#ffb4a2');
    if (lives <= 0) { end(false); return true; }
    return false;
  }
  function spawn(L) {
    var r = Math.random(), type = r < L.bad ? 'bad' : r < L.bad + 0.09 ? 'gold' : (level > 1 && lives < 3 && r < L.bad + 0.13) ? 'life' : 'pole';
    var x = 70 + Math.random() * (W - 140);
    if (type !== 'bad') { x = Math.max(lastX - 340, Math.min(lastX + 340, x)); lastX = x; }
    drops.push({ type: type, x: x, y: -50, a: Math.random() * 3, spin: Math.random() * 2.4 - 1.2, p: Math.random() * 6 });
  }
  function loop(now) {
    if (state !== 'play') return;
    var L = LEVELS[level], dt = Math.min(0.04, Math.max(0, (now - last) / 1000)); last = now;
    bx = Math.max(78, Math.min(W - 78, bx + dir * 640 * dt));
    timer -= dt;
    if (timer <= 0) { spawn(L); timer = Math.max(0.55, L.gap - score * 0.008); }
    var speed = (L.speed + score * 0.003) * H;
    flies.forEach(function (f) { f.p += dt * 1.5; });
    settle(dt);
    for (var i = drops.length - 1; i >= 0; i--) {
      var d = drops[i]; d.y += speed * dt; d.a += d.spin * dt; d.p += dt * 2;
      d.x = Math.max(40, Math.min(W - 40, d.x + Math.sin(d.p) * L.wind * dt));
      if (d.y > H - 80 && d.y < H - 22 && Math.abs(d.x - bx) < 90) {
        drops.splice(i, 1);
        if (d.type === 'bad') { if (loseLife(d.x, '− 1 life')) return; continue; }
        if (d.type === 'life') { lives = Math.min(3, lives + 1); note(d.x, H - 100, '+ 1 life', '#c9ffb0'); EG.tone(780, 0.25); hud(); continue; }
        score += d.type === 'gold' ? 3 : 1; hud(); place(false);
        note(d.x, H - 100, d.type === 'gold' ? '+3' : '+1', '#ffe7a0'); EG.tone(d.type === 'gold' ? 880 : 430, 0.12);
        if (score >= L.goal) return end(true);
      } else if (d.y > H + 50) {
        drops.splice(i, 1);
        if (d.type === 'pole' && ++missed % 4 === 0 && loseLife(d.x, '4 poles missed')) return;
      }
    }
    draw();
    for (var n = notes.length - 1; n >= 0; n--) {
      var m = notes[n]; m.t -= dt * 1.2; m.y -= 55 * dt;
      if (m.t <= 0) { notes.splice(n, 1); continue; }
      ctx.save(); ctx.globalAlpha = Math.min(1, m.t * 1.6); ctx.font = '700 26px Manrope, sans-serif'; ctx.textAlign = 'center';
      ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(15,24,15,.7)'; ctx.strokeText(m.text, m.x, m.y); ctx.fillStyle = m.c; ctx.fillText(m.text, m.x, m.y); ctx.restore();
    }
    raf = requestAnimationFrame(loop);
  }

  startBtn.addEventListener('click', function () {
    if (state === 'paused') run();
    else if (state === 'won') { select(level + 1); newFlies(); restart(); }
    else { notes = []; newFlies(); restart(); }
  });
  againBtn.addEventListener('click', function () { notes = []; newFlies(); restart(); });
  askBtn.addEventListener('click', function () { EG.toContact(LEVELS[level].ask); });
  pauseBtn.addEventListener('click', pause);
  $('#gReset').addEventListener('click', function () {
    if (!window.confirm('Reset your building progress and stars?')) return;
    stars = stars.map(function () { return 0; }); EG.store.set('stars', stars.join(',')); select(0);
  });

  function point(e) {
    if (state !== 'play') return;
    var r = cv.getBoundingClientRect(); bx = Math.max(78, Math.min(W - 78, (e.clientX - r.left) / r.width * W));
  }
  cv.addEventListener('pointerdown', point);
  cv.addEventListener('pointermove', point);
  var held = {};
  function keys() { dir = (held.right ? 1 : 0) - (held.left ? 1 : 0); }
  function keyName(k) { return (k === 'ArrowLeft' || k === 'a' || k === 'A') ? 'left' : (k === 'ArrowRight' || k === 'd' || k === 'D') ? 'right' : null; }
  addEventListener('keydown', function (e) {
    if (state !== 'play' || EG.dialogOpen() || /INPUT|TEXTAREA/.test(e.target.tagName)) return;
    var k = keyName(e.key); if (k) { e.preventDefault(); held[k] = true; keys(); }
  });
  addEventListener('keyup', function (e) { var k = keyName(e.key); if (k) { held[k] = false; keys(); } });
  Array.prototype.forEach.call(document.querySelectorAll('.game-pad button'), function (b) {
    b.addEventListener('pointerdown', function (e) { e.preventDefault(); dir = +b.dataset.dir; });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (n) { b.addEventListener(n, function () { dir = 0; }); });
    b.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  });
  document.addEventListener('visibilitychange', function () { if (document.hidden) { held = {}; pause(); } });
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (l) { if (l[0].intersectionRatio < 0.25) { held = {}; pause(); } }, { threshold: [0, 0.25] }).observe(cv);
    /* tuck the floating page controls away while the game is on screen */
    new IntersectionObserver(function (l) { $('.hud').classList.toggle('away', l[0].isIntersecting); }, { rootMargin: '-25% 0px -15% 0px' }).observe($('.game'));
  }

  /* start on the furthest unlocked level */
  var first = 0; while (first < LEVELS.length - 1 && stars[first]) first++;
  select(first); newFlies();
  if ('ResizeObserver' in window) new ResizeObserver(size).observe(cv); else addEventListener('resize', size);
  size();
  if (document.fonts && document.fonts.load) document.fonts.load('600 21px Fraunces').then(function () { rebuild(); draw(); }, function () {});
})();
