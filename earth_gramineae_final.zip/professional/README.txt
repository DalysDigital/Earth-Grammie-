EARTH GRAMINEAE - WEBSITE VERSION 2 (natural / professional look)

INSTALL (cPanel File Manager)
1. Back up the current index.php (rename it, e.g. index-comic.php).
2. Upload the zip to the folder that holds index.php and config.php, then Extract.
3. Hard refresh (Ctrl+F5).

ADDS OR REPLACES ONLY: index.php, grove.css, grove.js, builder.js, assets/fonts/, README.txt
NOT TOUCHED: assets/images/, logo, config.php, database, admin, styles.css, script.js

KEEP styles.css: the top banner picture path is read from it
(fallback: assets/images/img_24.jpeg).

IF YOU INSTALLED THE COMIC VERSION, these are no longer used and can be deleted:
comic.css, comic.js, and in assets/fonts/ the bangers-* and comic-neue-* files
with their two licence files. (Delete only after you are happy with version 2.)

GAME: Bamboo Builder, 6 levels, unlocked in order
1 Garden Gazebo (12 poles)   4 Welcome Gate (20)
2 Twin Gazebos (16)          5 Moon Bridge (22)
3 Tiered Pavilion (20)       6 Eco Retreat (28)
Progress and stars are saved in each visitor's own browser.
Level targets and speeds are in the LEVELS list in builder.js (goal, speed, gap, bad, wind).

NOTES
- Custom CSS saved in the admin still loads; remove old rules if something looks odd.
- The admin "primary colour" sets the dark green areas (mission, contact card, footer).
- Fonts (Fraunces, Manrope; licences included) are local. No CDN.
