/* Earth Gramineae — site interactions: growing bamboo, falling leaves, viewer, enquiry form. No libraries. */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var store = {
    get: function (k) { try { return localStorage.getItem('eg_' + k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem('eg_' + k, v); } catch (e) {} }
  };

  /* ---------- Sound (off until the visitor turns it on) ---------- */
  var soundOn = false, actx = null;
  function tone(freq, dur, type, delay) {
    if (!soundOn) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    actx = actx || new AC();
    if (actx.state === 'suspended') actx.resume();
    var t = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'triangle';
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(freq * 0.55, t + dur);
    g.gain.setValueAtTime(0.16, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(t); o.stop(t + dur);
  }
  var soundBtn = $('#soundBtn');
  soundBtn.addEventListener('click', function () {
    soundOn = !soundOn;
    soundBtn.textContent = 'Sound: ' + (soundOn ? 'On' : 'Off');
    soundBtn.setAttribute('aria-pressed', soundOn);
    tone(620, 0.12);
  });

  var NS = 'http://www.w3.org/2000/svg';
  function seeded(n) { return function () { n = (n * 16807) % 2147483647; return (n - 1) / 2147483646; }; }
  function el(tag, attrs, parent) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  var LEAF = 'M0 0C12-11 36-12 62 0C36 12 12 11 0 0Z';
  function leafPath(parent, x, y, angle, scale, fill) {
    return el('path', { d: LEAF, fill: fill, transform: 'translate(' + x + ' ' + y + ') rotate(' + angle + ') scale(' + scale + ')' }, parent);
  }

  /* ---------- Bamboo that grows along both edges while scrolling ---------- */
  var stalks = [];
  var TONES = [['#47602c', '#a9bd62', '#33471f'], ['#8c6f2f', '#e6cb82', '#5f4a1f'], ['#2f4a2b', '#74935a', '#1f331d']];
  var GREENS = ['#4f7034', '#6d8f3d', '#8aa84a', '#3c5a2a'];
  function buildRails() {
    stalks = [];
    $$('.bamboo-rail').forEach(function (rail, side) {
      rail.textContent = '';
      var w = rail.clientWidth, h = rail.clientHeight;
      if (!w || !h) return;
      var svg = el('svg', { viewBox: '0 0 ' + w + ' ' + h, preserveAspectRatio: 'none' }, rail);
      var defs = el('defs', {}, svg);
      TONES.forEach(function (t, i) {
        var g = el('linearGradient', { id: 'culm' + side + i }, defs);
        [[0, t[0]], [0.35, t[1]], [0.65, t[0]], [1, t[2]]].forEach(function (s) { el('stop', { offset: s[0], 'stop-color': s[1] }, g); });
      });
      var root = el('g', side ? { transform: 'translate(' + w + ' 0) scale(-1 1)' } : {}, svg);
      var plan = w < 40 ? [[8, 6, 0.94, 0]] : [[w * 0.07, w * 0.07, 0.7, 2], [w * 0.38, w * 0.085, 0.84, 1], [w * 0.2, w * 0.13, 0.97, 0]];
      plan.forEach(function (p, n) {
        var rnd = seeded(101 + side * 37 + n * 11), x = p[0], width = Math.max(5, Math.min(17, p[1]));
        var stalk = { segs: [], sprouts: [], max: p[2] * h, h: h, x: x, lag: n * 0.04 };
        var body = el('g', {}, root), foliage = el('g', {}, root), base = 0, i = 0;
        var reach = Math.max(0.34, Math.min(1.05, (w - x - 4) / 66));
        while (base < stalk.max) {
          var len = (w < 40 ? 56 : 66) + rnd() * 38, wd = width * (1 - 0.35 * base / h);
          var seg = el('g', { 'class': 'seg' }, body);
          el('rect', { x: x - wd / 2, y: h - base - len, width: wd, height: len - 1.5, rx: 2, fill: 'url(#culm' + side + p[3] + ')' }, seg);
          el('rect', { x: x - wd / 2 - 1.5, y: h - base - len - 1, width: wd + 3, height: 3.5, rx: 1.5, fill: TONES[p[3]][2] }, seg);
          el('rect', { x: x - wd / 2 - 1, y: h - base - len + 3, width: wd + 2, height: 1.2, fill: '#efe3b4', opacity: 0.7 }, seg);
          stalk.segs.push({ el: seg, base: base, len: len });
          base += len;
          if (rnd() < 0.82) {
            var dir = (i + n) % 3 === 0 && x > 30 ? -1 : 1;
            var holder = el('g', { transform: 'translate(' + x + ' ' + (h - base) + ') scale(' + (dir * (dir > 0 ? reach : reach * 0.6)) + ' ' + reach + ')' }, foliage);
            var sprout = el('g', { 'class': 'sprout' }, holder), sw = el('g', { 'class': 'sway' }, sprout);
            sw.style.animationDelay = (-rnd() * 6) + 's';
            el('path', { d: 'M0 0Q10-5 22-14', stroke: '#6f7f3a', 'stroke-width': 2, fill: 'none' }, sw);
            var count = 2 + Math.floor(rnd() * 3);
            for (var k = 0; k < count; k++) {
              leafPath(sw, 8 + k * 5, -5 - k * 3, -48 + k * 34 + rnd() * 20, 0.5 + rnd() * 0.32, GREENS[Math.floor(rnd() * 4)]);
            }
            stalk.sprouts.push({ el: sprout, at: base });
          }
          i++;
        }
        var tip = el('g', {}, root), crown = el('g', { transform: 'scale(' + reach + ')' }, tip);
        el('path', { d: 'M-4 2Q-2-22 0-34Q2-22 4 2Z', fill: '#8aa84a' }, tip);
        [[-18, 0.75], [-62, 0.62], [-104, 0.5], [12, 0.45]].forEach(function (a, k) { leafPath(crown, 0, -6, a[0], a[1], GREENS[k]); });
        stalk.tip = tip;
        stalks.push(stalk);
      });
    });
    grow();
  }
  function grow() {
    var max = document.documentElement.scrollHeight - innerHeight;
    var p = calm ? 1 : max > 0 ? Math.max(0, Math.min(1, scrollY / max)) : 0;
    stalks.forEach(function (s) {
      /* quick early growth so the motion is visible from the first scroll */
      var q = Math.pow(Math.max(0, Math.min(1, (p - s.lag) / (1 - s.lag))), 0.7);
      var tall = Math.min(s.max, s.h * 0.16 + (s.max - s.h * 0.16) * q);
      var last = 0;
      s.segs.forEach(function (g) {
        var k = Math.max(0, Math.min(1, (tall - g.base) / g.len));
        g.el.style.display = k ? '' : 'none';
        if (k) { g.el.style.transform = 'scaleY(' + k.toFixed(3) + ')'; last = g.base + g.len * k; }
      });
      s.sprouts.forEach(function (sp) { sp.el.classList.toggle('on', tall >= sp.at); });
      s.tip.setAttribute('transform', 'translate(' + s.x + ' ' + (s.h - last) + ')');
    });
  }
  var railSize = '', resizeTimer;
  addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      var r = $('.bamboo-rail.right'), key = r.clientWidth + 'x' + r.clientHeight;
      if (key !== railSize) { railSize = key; buildRails(); }
    }, 180);
  });

  /* ---------- Bamboo grove silhouettes ---------- */
  function grove(host, height, count, colours, seed) {
    var rnd = seeded(seed);
    var svg = el('svg', { viewBox: '0 0 1440 ' + height, preserveAspectRatio: 'xMidYMax slice' }, host);
    for (var i = 0; i < count; i++) {
      var x = (i + rnd()) * 1440 / count, tall = height * (0.28 + rnd() * rnd() * 0.68), lean = (rnd() - 0.5) * 44;
      var c = colours[Math.floor(rnd() * colours.length)], w = 2 + rnd() * 5, step = 22 + rnd() * 16;
      for (var y = 0; y < tall; y += step) {
        var a = y / tall, top = Math.min(tall, y + step - 2.5), b = top / tall;
        el('line', { x1: x + lean * a * a, y1: height - y, x2: x + lean * b * b, y2: height - top, stroke: c, 'stroke-width': w * (1 - a * 0.55) }, svg);
        if (y > tall * 0.3 && rnd() < 0.75) {
          var side = rnd() < 0.5 ? 1 : -1, px = x + lean * b * b, py = height - top, ex = px + side * (6 + rnd() * 12), ey = py - 3 - rnd() * 8;
          el('line', { x1: px, y1: py, x2: ex, y2: ey, stroke: c, 'stroke-width': 1 }, svg);
          for (var k = 0; k < 3; k++) leafPath(svg, ex, ey, (side > 0 ? 0 : 180) + side * (-30 + k * 32 + rnd() * 18), 0.22 + rnd() * 0.3, c);
        }
      }
      leafPath(svg, x + lean, height - tall, -60 - rnd() * 60, 0.3 + rnd() * 0.2, c);
    }
    el('path', { d: 'M0 ' + height + 'V' + (height - 10) + 'Q360 ' + (height - 26) + ' 720 ' + (height - 8) + 'T1440 ' + (height - 12) + 'V' + height + 'Z', fill: colours[0] }, svg);
  }
  var heroGrove = $('.hero-grove'); if (heroGrove) grove(heroGrove, 280, 46, ['#0c150c', '#142213', '#1d3018'], 7);
  if ($('.play .grove')) grove($('.play .grove'), 150, 60, ['#0f180f'], 23);
  if ($('footer .grove')) grove($('footer .grove'), 120, 52, ['#172116'], 41);
  var footPaint = $('footer .grove'); if (footPaint) $$('path,line', footPaint).forEach(function (n) {
    n.style[n.tagName === 'line' ? 'stroke' : 'fill'] = 'var(--forest)';
  });

  /* ---------- Falling leaves ---------- */
  var sky = $('#leafCanvas'), lx = sky.getContext('2d'), leaves = [], extra = [], leavesOn = false, leafRaf = 0;
  var lastY = scrollY, wind = 0, mouse = { x: -999, y: -999 };
  var shape = window.Path2D ? new Path2D(LEAF) : null;
  function newLeaf(top) {
    return { x: Math.random() * innerWidth, y: top ? -40 : Math.random() * innerHeight, s: 0.2 + Math.random() * 0.3, vy: 22 + Math.random() * 36,
      p: Math.random() * 6.3, r: Math.random() * 6.3, vr: (Math.random() - 0.5) * 1.4, c: ['#6d8f3d', '#8aa84a', '#4f7034', '#c9a45c'][Math.floor(Math.random() * 4)] };
  }
  function sizeSky() {
    var d = Math.min(2, devicePixelRatio || 1);
    sky.width = sky.clientWidth * d; sky.height = sky.clientHeight * d; lx.setTransform(d, 0, 0, d, 0, 0);
    var want = innerWidth < 700 ? 10 : 26;
    while (leaves.length < want) leaves.push(newLeaf(false));
    leaves.length = want;
  }
  var leafLast = 0;
  function paintLeaf(l, alpha) {
    lx.save(); lx.globalAlpha = alpha; lx.translate(l.x, l.y); lx.rotate(l.r);
    lx.scale(l.s, l.s * (0.45 + 0.55 * Math.abs(Math.sin(l.p)))); lx.translate(-31, 0);
    lx.fillStyle = l.c; lx.fill(shape);
    lx.strokeStyle = 'rgba(255,255,255,.35)'; lx.lineWidth = 1; lx.beginPath(); lx.moveTo(2, 0); lx.lineTo(52, 0); lx.stroke();
    lx.restore();
  }
  function fall(now) {
    leafRaf = 0;
    var dt = Math.min(0.05, (now - leafLast) / 1000 || 0.016); leafLast = now;
    lx.clearRect(0, 0, innerWidth, innerHeight);
    var dy = scrollY - lastY; lastY = scrollY;
    wind += Math.max(-60, Math.min(60, dy)) * 1.6; wind *= 0.94;
    if (leavesOn) leaves.forEach(function (l, i) {
      l.p += dt * 1.7; l.r += (l.vr + wind * 0.004) * dt;
      l.x += (Math.sin(l.p) * 28 + 14 + wind * 0.5) * dt; l.y += (l.vy - dy * 6) * dt;
      var mx = l.x - mouse.x, my = l.y - mouse.y, dist = Math.sqrt(mx * mx + my * my);
      if (dist < 90 && dist > 1) { l.x += mx / dist * (90 - dist) * dt * 4; l.y += my / dist * (90 - dist) * dt * 4; }
      if (l.y > innerHeight + 40) leaves[i] = newLeaf(true);
      if (l.y < -60) l.y = innerHeight + 30;
      if (l.x > innerWidth + 40) l.x = -30; if (l.x < -40) l.x = innerWidth + 30;
      paintLeaf(l, innerWidth < 700 ? 0.55 : 0.75);
    });
    for (var i = extra.length - 1; i >= 0; i--) {
      var e = extra[i]; e.life -= dt; e.vy += 190 * dt; e.x += e.vx * dt; e.y += e.vy * dt; e.r += e.vr * 3 * dt; e.p += dt * 6;
      if (e.life <= 0) extra.splice(i, 1); else paintLeaf(e, Math.min(1, e.life * 1.4));
    }
    if (!document.hidden && (leavesOn || extra.length)) leafRaf = requestAnimationFrame(fall);
  }
  function wake() { if (!leafRaf && shape) { leafLast = performance.now(); lastY = scrollY; leafRaf = requestAnimationFrame(fall); } }
  function burst(x, y, n) {
    if (calm || !shape) return;
    for (var i = 0; i < (n || 9); i++) {
      var l = newLeaf(false); l.x = x; l.y = y; l.s *= 0.85; l.vx = (Math.random() - 0.5) * 240; l.vy = -60 - Math.random() * 130; l.life = 0.7 + Math.random() * 0.6;
      extra.push(l);
    }
    wake();
  }
  function burstAt(node, n) { var r = node.getBoundingClientRect(); burst(r.left + r.width / 2, r.top + r.height / 2, n); }
  addEventListener('resize', sizeSky);
  addEventListener('pointermove', function (e) { if (e.pointerType === 'mouse') { mouse.x = e.clientX; mouse.y = e.clientY; } }, { passive: true });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) wake(); });
  document.addEventListener('click', function (e) {
    if (e.target.closest('a,button,input,textarea,label,summary,canvas,.flip,.lightbox,.badge-pop,.game,form')) return;
    burst(e.clientX, e.clientY, 6);
  });
  var fxBtn = $('#fxBtn');
  function setLeaves(on) {
    leavesOn = on; fxBtn.textContent = 'Falling leaves: ' + (on ? 'On' : 'Off'); fxBtn.setAttribute('aria-pressed', on); wake();
  }
  fxBtn.addEventListener('click', function () { setLeaves(!leavesOn); store.set('leaves', leavesOn ? 'on' : 'off'); });
  sizeSky();
  setLeaves(store.get('leaves') ? store.get('leaves') === 'on' : !calm);

  /* ---------- Menu, active link, scroll bamboo ---------- */
  var toggle = $('.menu-toggle'), nav = $('.nav');
  function menu(open) {
    nav.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', open);
    toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    $('.site-header').classList.toggle('solid', open || scrollY > 40);
  }
  toggle.addEventListener('click', function () { menu(!nav.classList.contains('open')); });
  nav.addEventListener('click', function (e) { if (e.target.closest('a')) menu(false); });

  var header = $('.site-header'), links = $$('.nav a'), ticking = false;
  function onScroll() {
    ticking = false;
    header.classList.toggle('solid', scrollY > 40 || nav.classList.contains('open'));
    grow();
    var current = '';
    links.forEach(function (a) {
      var s = $(a.getAttribute('href'));
      if (s && s.getBoundingClientRect().top < innerHeight * 0.4) current = a.getAttribute('href');
    });
    links.forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === current); });
  }
  addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });

  /* ---------- Reveal on scroll ---------- */
  var reveals = $$('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (list) {
      list.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(function (el) { io.observe(el); });
  } else reveals.forEach(function (el) { el.classList.add('in'); });

  /* ---------- Principle cards ---------- */
  $$('.flip').forEach(function (card) {
    card.setAttribute('role', 'button'); card.setAttribute('tabindex', '0'); card.setAttribute('aria-pressed', 'false');
    function flip() {
      var on = card.getAttribute('aria-pressed') !== 'true';
      card.setAttribute('aria-pressed', on);
      if (on) tone(520, 0.12);
    }
    card.addEventListener('click', flip);
    card.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } });
  });

  /* ---------- Dialog helpers ---------- */
  var openDialog = null, returnFocus = null;
  function show(d, focusEl) {
    returnFocus = document.activeElement; openDialog = d; d.hidden = false;
    document.body.style.overflow = 'hidden'; focusEl.focus();
  }
  function hide(restore) {
    if (!openDialog) return;
    openDialog.hidden = true; openDialog = null; document.body.style.overflow = '';
    if (restore !== false && returnFocus && returnFocus.focus) returnFocus.focus({ preventScroll: true });
  }

  /* ---------- Hidden golden leaves ---------- */
  var found = (store.get('golden') || '').split(',').filter(Boolean);
  var gleaves = $$('.gleaf'), countEl = $('#leafCount'), badge = $('#badge');
  function paintFound() {
    gleaves.forEach(function (s) { s.classList.toggle('found', found.indexOf(s.dataset.leaf) > -1); });
    countEl.textContent = found.length;
  }
  gleaves.forEach(function (s) {
    s.addEventListener('click', function () {
      if (found.indexOf(s.dataset.leaf) > -1) return;
      burstAt(s, 16); tone(660, 0.12); tone(990, 0.16, 'triangle', 0.1);
      found.push(s.dataset.leaf); store.set('golden', found.join(',')); paintFound();
      if (found.length === gleaves.length) setTimeout(function () { show(badge, $('#badgeClose')); }, 600);
    });
  });
  paintFound();
  $('#badgeClose').addEventListener('click', function () { hide(); });

  /* ---------- Project viewer ---------- */
  var box = $('#lightbox'), items = $$('.project-open'), idx = 0;
  function render(i) {
    idx = (i + items.length) % items.length;
    var it = items[idx], img = $('img', it);
    $('#lightboxImg').src = img.getAttribute('src');
    $('#lightboxImg').alt = it.dataset.title;
    $('#lightboxTitle').textContent = it.dataset.title;
    $('#lightboxDesc').textContent = it.dataset.desc || '';
    $('#lightboxCount').textContent = 'Project ' + (idx + 1) + ' of ' + items.length;
    var one = items.length < 2; $('#prevBtn').hidden = one; $('#nextBtn').hidden = one;
  }
  items.forEach(function (it, i) {
    it.addEventListener('click', function () { render(i); show(box, $('.lightbox-close')); tone(450, 0.14); });
  });
  $('.lightbox-close').addEventListener('click', function () { hide(); });
  $('#prevBtn').addEventListener('click', function () { render(idx - 1); tone(400, 0.08); });
  $('#nextBtn').addEventListener('click', function () { render(idx + 1); tone(500, 0.08); });
  box.addEventListener('click', function (e) { if (e.target === box) hide(); });
  var sx = null;
  box.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
  box.addEventListener('touchend', function (e) {
    if (sx === null) return;
    var d = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(d) > 60) render(idx + (d < 0 ? 1 : -1));
  });
  $('#likeBtn').addEventListener('click', function () {
    var t = items[idx].dataset.title; hide(false); toContact(t + ' (like in your gallery)');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (openDialog) hide(); else menu(false); }
    if (!openDialog) return;
    if (openDialog === box && e.key === 'ArrowLeft') render(idx - 1);
    if (openDialog === box && e.key === 'ArrowRight') render(idx + 1);
    if (e.key === 'Tab') {
      var f = $$('button', openDialog).filter(function (b) { return !b.hidden; });
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ---------- Contact form ---------- */
  var form = $('#contactForm'), nameEl = $('#name'), projEl = $('#project'), msgEl = $('#message');
  var chips = $$('.chip');
  chips.forEach(function (c) {
    c.addEventListener('click', function () {
      var on = c.getAttribute('aria-pressed') !== 'true';
      c.setAttribute('aria-pressed', on);
      projEl.value = chips.filter(function (x) { return x.getAttribute('aria-pressed') === 'true'; }).map(function (x) { return x.textContent; }).join(', ');
      if (on) { burstAt(c, 5); tone(560, 0.1); }
    });
  });
  projEl.addEventListener('input', function () { chips.forEach(function (c) { c.setAttribute('aria-pressed', 'false'); }); });
  function toContact(project) {
    projEl.value = project;
    chips.forEach(function (c) { c.setAttribute('aria-pressed', 'false'); });
    $('#contact .reveal').classList.add('in');
    form.scrollIntoView({ block: 'start' });
    nameEl.focus({ preventScroll: true });
  }
  function body() {
    return 'Hello Earth Gramineae,\n\nName: ' + nameEl.value.trim() +
      '\nProject / service: ' + (projEl.value.trim() || 'Not specified') +
      '\n\n' + msgEl.value.trim();
  }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    burstAt($('button[type=submit]', form)); tone(700, 0.2);
    var url = 'https://wa.me/' + form.dataset.wa + '?text=' + encodeURIComponent(body());
    var w = window.open(url, '_blank');
    if (w) w.opener = null; else location.href = url;
  });
  $('#emailBtn').addEventListener('click', function () {
    if (!form.reportValidity()) return;
    location.href = 'mailto:' + form.dataset.email + '?subject=' +
      encodeURIComponent('Project enquiry — ' + (projEl.value.trim() || nameEl.value.trim())) +
      '&body=' + encodeURIComponent(body());
  });
  $('#year').textContent = new Date().getFullYear();

  /* ---------- Shared with the game ---------- */
  window.EG = { tone: tone, burst: burst, toContact: toContact, store: store, calm: calm, dialogOpen: function () { return !!openDialog; } };
  buildRails();
  var rr = $('.bamboo-rail.right'); railSize = rr.clientWidth + 'x' + rr.clientHeight;
  addEventListener('load', grow);
  onScroll();
})();
