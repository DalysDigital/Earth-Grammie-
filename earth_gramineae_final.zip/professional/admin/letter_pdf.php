<?php
require_once __DIR__.'/../config.php';$autoload=__DIR__.'/../vendor/autoload.php';if(!file_exists($autoload)){header('Location: letter_view.php?id='.(int)$_GET['id']);exit;}require $autoload;
use Dompdf\Dompdf;
$id=(int)$_GET['id'];ob_start();include __DIR__.'/letter_view.php';$html=ob_get_clean();$html=preg_replace('/<div class=tools>.*?<\/div>/s','',$html);$d=new Dompdf();$d->loadHtml($html);$d->setPaper('A4','portrait');$d->render();$d->stream('Earth-Gramineae-Letter-'.$id.'.pdf',['Attachment'=>true]);
