<?php
require_once __DIR__.'/migrate.php';
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $host=trim($_POST['db_host']??'localhost'); $name=trim($_POST['db_name']??'earth_gramineae');
  $user=trim($_POST['db_user']??''); $pass=$_POST['db_pass']??''; $base=rtrim(trim($_POST['base_url']??''),'/');
  try{
    $pdo=new PDO("mysql:host=$host;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $safe=str_replace('`','',$name);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$safe` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$safe`");
    eg_migrate($pdo);
    $cfg=['db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,'base_url'=>$base];
    if(file_put_contents(__DIR__.'/config.local.php',"<?php\nreturn ".var_export($cfg,true).";\n")===false) throw new RuntimeException('Unable to write config.local.php. Check folder permissions.');
    $defaults=['site_name'=>'Earth Gramineae','phone'=>'+91 60330 96156','email'=>'earth.gramineae@gmail.com','instagram'=>'@earth.gramineae','address'=>'Pohkseh Nongthymmai, Shillong, East Khasi Hills, Meghalaya 793006','smtp_host'=>'','smtp_port'=>'587','smtp_user'=>'','smtp_pass'=>'','smtp_secure'=>'tls','smtp_from_name'=>'Earth Gramineae','smtp_from_email'=>''];
    $st=$pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)"); foreach($defaults as $k=>$v)$st->execute([$k,$v]);
    $home=['hero_title'=>'Future from the past.','hero_copy'=>'Bamboo-led architecture, furniture and eco-living spaces where cultural heritage meets contemporary design.','intro_display'=>'Building with a material that grows back.','intro_p1'=>'Established in 2019, Earth Gramineae is dedicated to crafting innovative, eco-conscious structures using bamboo—a fast-growing, renewable resource.','intro_p2'=>'We specialize in bespoke garden landscapes, furniture and eco-living spaces that harmonize with nature.','meta_title'=>'Earth Gramineae — Future From The Past','meta_description'=>'Eco-sustainable bamboo architecture, furniture, garden landscapes and eco-living spaces from Meghalaya.'];
    $q=$pdo->prepare('SELECT id,content_json FROM pages WHERE slug=? LIMIT 1'); $q->execute(['home']); $existing=$q->fetch();
    $homeJson=json_encode($home,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if($existing){$u=$pdo->prepare("UPDATE pages SET title=?,content_json=IFNULL(NULLIF(content_json,''),?),custom_css=IFNULL(custom_css,'') WHERE id=?");$u->execute(['Home',$homeJson,$existing['id']]);}
    else{$i=$pdo->prepare('INSERT INTO pages(slug,title,content_json,custom_css) VALUES(?,?,?,?)');$i->execute(['home','Home',$homeJson,'']);}
    $theme=['primary'=>'#172116','custom_css'=>'']; $q=$pdo->prepare('SELECT id,content_json FROM pages WHERE slug=? LIMIT 1'); $q->execute(['theme']); $existing=$q->fetch(); $themeJson=json_encode($theme); if($existing){$u=$pdo->prepare("UPDATE pages SET title=?,content_json=IFNULL(NULLIF(content_json,''),?) WHERE id=?");$u->execute(['Theme',$themeJson,$existing['id']]);} else {$i=$pdo->prepare('INSERT INTO pages(slug,title,content_json,custom_css) VALUES(?,?,?,?)');$i->execute(['theme','Theme',$themeJson,'']);}
    $adminEmail=trim($_POST['admin_email']??''); $adminPass=$_POST['admin_password']??''; $adminName=trim($_POST['admin_name']??'Earth Gramineae Admin');
    if(!filter_var($adminEmail,FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Enter a valid administrator email.');
    if(strlen($adminPass)<8) throw new InvalidArgumentException('Administrator password must be at least 8 characters.');
    $q=$pdo->prepare('SELECT id FROM admins WHERE email=? LIMIT 1'); $q->execute([$adminEmail]); $existingAdmin=$q->fetch(); $hash=password_hash($adminPass,PASSWORD_DEFAULT);
    if($existingAdmin){$u=$pdo->prepare('UPDATE admins SET name=?,password_hash=?,role=? WHERE id=?');$u->execute([$adminName,$hash,'super_admin',$existingAdmin['id']]);}
    else{$i=$pdo->prepare('INSERT INTO admins(name,email,password_hash,role) VALUES(?,?,?,?)');$i->execute([$adminName,$adminEmail,$hash,'super_admin']);}
    $msg='<div class="ok">Database installed/repaired successfully. <a href="admin/login.php">Open Admin Login →</a></div>';
  }catch(Throwable $e){$msg='<div class="err"><b>Setup failed:</b> '.htmlspecialchars($e->getMessage()).'</div>';}
}
?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:Arial,sans-serif;background:#20264a;margin:0;padding:28px;color:#222}.card{max-width:640px;margin:auto;background:#fff;padding:28px;border-radius:18px;box-shadow:0 20px 60px #0003}.logo{width:110px;height:110px;object-fit:contain}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}input{width:100%;padding:13px;box-sizing:border-box;margin:6px 0 14px;border:1px solid #ddd;border-radius:9px}button{padding:14px 20px;background:#20264a;color:white;border:0;border-radius:9px;width:100%;font-weight:bold}.ok{background:#e8f4e8;padding:14px;border-radius:9px}.err{background:#fdeaea;padding:14px;border-radius:9px;color:#9b1515;word-break:break-word}@media(max-width:600px){.row{grid-template-columns:1fr}}</style></head><body><div class=card><img class=logo src="assets/images/img_01.png"><h1>Earth Gramineae Setup</h1><?= $msg ?><p>This installer is safe to run on an existing database: it repairs missing columns instead of deleting your data.</p><form method=post><div class=row><div>DB Host<input name=db_host value="localhost" required></div><div>DB Name<input name=db_name value="earth_gramineae" required></div><div>DB User<input name=db_user required></div><div>DB Password<input type=password name=db_pass></div></div><label>Base URL</label><input name=base_url placeholder="https://example.com"><h3>Super Administrator</h3><label>Name</label><input name=admin_name value="Earth Gramineae Admin" required><label>Email</label><input type=email name=admin_email required><label>Password</label><input type=password name=admin_password required minlength=8><button>Install / Repair</button></form></div></body></html>
