<?php
require_once __DIR__.'/config.php';
try { $pdo=db(); $settings=settings($pdo); $home=page_data($pdo,'home'); $theme=page_data($pdo,'theme'); $projects=projects($pdo); } catch(Throwable $e) { $settings=[]; $home=[]; $theme=[]; $projects=[]; }
function eh($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
$primary=$theme['primary']??$settings['theme_primary']??'#172116';
$css=$theme['_custom_css']??''; $css.=$settings['global_css']??'';
$phone=$settings['phone']??'+91 60330 96156'; $email=$settings['email']??'earth.gramineae@gmail.com';
$wa=preg_replace('/\D+/','',$phone);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="<?=eh($primary)?>">
  <meta name="description" content="<?=eh($home['meta_description']??'Earth Gramineae — eco-sustainable bamboo architecture, furniture, garden landscapes and eco-living spaces from Meghalaya.')?>">
  <title><?=eh($home['meta_title']??'Earth Gramineae — Future From The Past')?></title>
  <link rel="icon" href="assets/images/img_01.png">
  <link rel="stylesheet" href="styles.css"><style><?= $css ?></style>
</head>
<body>
  <div class="grain"></div>
  <header class="site-header" id="top">
    <a class="brand" href="#top" aria-label="Earth Gramineae home">
      <span class="brand-mark"><img src="assets/images/img_01.png" alt="Earth Gramineae mark"></span>
      <span><b>Earth</b> Gramineae</span>
    </a>
    <button class="menu-toggle" aria-label="Open navigation"><span></span><span></span></button>
    <nav class="nav">
      <a href="#about">About</a><a href="#mission">Mission</a><a href="#work">Work</a><a href="#principles">Approach</a><a href="#contact">Contact</a>
    </nav>
  </header>

  <main>
    <section class="hero">
      <div class="hero-image"></div>
      <div class="hero-overlay"></div>
      <div class="hero-content reveal">
        <p class="eyebrow">EARTH GRAMINEAE · EST. 2019 · MEGHALAYA</p>
        <h1><?= $home['hero_title']??'Future<br><em>from the past.</em>' ?></h1>
        <p class="hero-copy"><?=eh($home['hero_copy']??'Bamboo-led architecture, furniture and eco-living spaces where cultural heritage meets contemporary design.')?></p>
        <div class="hero-actions"><a class="btn btn-light" href="#work">Explore our work <span>↘</span></a><a class="text-link light" href="#contact">Start a conversation</a></div>
      </div>
      <div class="hero-note">BAMBOO · DESIGN · CRAFT · SUSTAINABILITY</div>
      <div class="scroll-cue"><span></span> SCROLL TO EXPLORE</div>
    </section>

    <section class="intro section" id="about">
      <div class="section-tag reveal">01 / INTRODUCTION</div>
      <div class="intro-grid">
        <div class="portrait-wrap reveal"><img src="assets/images/img_03.jpeg" alt="Bamboo gazebo in a green landscape"><span class="image-caption">Crafted in harmony with Meghalaya's landscape.</span></div>
        <div class="intro-copy reveal">
          <p class="display"><?=eh($home['intro_display']??'Building with a material that grows back.')?></p>
          <p><?=eh($home['intro_p1']??'Established in 2019, Earth Gramineae is dedicated to crafting innovative, eco-conscious structures using bamboo—a fast-growing, renewable resource. We specialize in creating bespoke garden landscapes, furniture, and eco-living spaces that harmonize with nature.')?></p>
          <p><?=eh($home['intro_p2']??'Our mission is to deliver distinctive, sustainable products, carefully designed to meet modern aesthetic and environmental needs. By blending time-honored materials with advanced building techniques, we ensure that every project embodies efficiency, beauty, and eco-friendly craftsmanship.')?></p>
          <div class="stat-row"><div><strong>2019</strong><span>Established</span></div><div><strong>Bamboo</strong><span>Core material</span></div><div><strong>Meghalaya</strong><span>Rooted here</span></div></div>
        </div>
      </div>
    </section>

    <section class="mission section dark" id="mission">
      <div class="section-tag reveal">02 / MISSION</div>
      <div class="mission-grid">
        <div class="mission-copy reveal">
          <h2>Culture is our foundation.<br><em>Nature is our future.</em></h2>
          <p>At Earth Gramineae, our mission is to showcase the extraordinary potential of bamboo as a cornerstone for building a more sustainable and eco-conscious future. Bamboo, deeply embedded in our cultural heritage, especially in the rural landscapes of Meghalaya, has long been valued for its versatility and resilience. Today, we seek to bring its transformative power to the forefront of modern innovation.</p>
          <p>We are dedicated to demonstrating that bamboo is not just a traditional resource, but a pivotal solution to addressing some of the most urgent environmental and economic challenges of our time. By promoting its use, we can make significant strides in the fight against deforestation, reducing reliance on less sustainable building materials, and combating the global issue of carbon emissions. The regenerative nature of bamboo allows us to cultivate it quickly, ensuring that its use has a minimal ecological footprint while providing a sustainable future.</p>
        </div>
        <div class="mission-image reveal"><img src="assets/images/img_04.jpeg" alt="Carved bamboo planter with a plant"><div class="vertical-label">TRADITION × INNOVATION</div></div>
      </div>
    </section>

    <section class="founder section">
      <div class="section-tag reveal">03 / THE FOUNDER</div>
      <div class="founder-grid">
        <div class="founder-copy reveal">
          <p class="kicker">Denzil Lyngdoh</p><h2>Founder &amp; Director</h2>
          <p>Denzil Lyngdoh, born and raised in Meghalaya, India, left a flourishing career as a disc jockey in the music industry to pursue his passion for eco-sustainable architecture. In 2019, he established Earth Gramineae, driven by his deep connection to bamboo and its potential to create sustainable, beautiful structures.</p>
          <p>Inspired by the material's cultural roots and its ability to offer eco-friendly solutions, Denzil leads the company in collaboration with innovative designers and architects to develop nature-inspired, sustainable solutions for the modern world.</p>
          <p>Denzil’s vision extends beyond creating eco-conscious products; he strives to inspire a global shift toward sustainability by leveraging bamboo as a pivotal resource. His mission is to cultivate sustainable practices that honor both the culture and landscape of Meghalaya, while advancing the possibilities of bamboo in building a greener, more promising future.</p>
        </div>
        <div class="founder-photo reveal"><img src="assets/images/img_06.jpeg" alt="Denzil Lyngdoh outdoors"><div class="founder-badge">MEGHALAYA<br>INDIA</div></div>
      </div>
    </section>

    <section class="principles section" id="principles">
      <div class="section-tag reveal">04 / PROFESSIONALISM</div>
      <div class="principles-head reveal"><h2>Built with <em>integrity.</em></h2><p>Earth Gramineae stands on a foundation of professionalism, where every project is executed with the utmost attention to quality, integrity, and customer satisfaction. Our team of skilled designers, architects, and builders is committed to delivering eco-sustainable structures that reflect the highest standards of craftsmanship and innovation.</p></div>
      <div class="principles-grid">
        <article class="principle reveal"><span>01</span><h3>Commitment to Excellence</h3><p>From the initial consultation to the final build, we ensure that each step of the process meets rigorous standards of sustainability and precision. We adhere to modern building practices that respect both tradition and cutting-edge techniques.</p></article>
        <article class="principle reveal"><span>02</span><h3>Transparency &amp; Collaboration</h3><p>At Earth Gramineae, we believe in fostering strong partnerships with our clients. We maintain open lines of communication and involve our customers in the design and building process, ensuring their visions are realized in harmony with our eco-conscious goals.</p></article>
        <article class="principle reveal"><span>03</span><h3>Sustainability in Action</h3><p>Our professionalism is not just reflected in the end product but in how we source materials and manage each project. By using bamboo—a rapidly renewable resource—we ensure that every structure we create reduces environmental impact and contributes to a more sustainable future.</p></article>
        <article class="principle reveal"><span>04</span><h3>Cultural Respect &amp; Innovation</h3><p>Earth Gramineae's work is rooted in the rich heritage of Meghalaya and beyond. We blend cultural respect with modern innovation, resulting in designs that honor tradition while embracing forward-thinking solutions.</p></article>
        <article class="principle reveal"><span>05</span><h3>Client-Centric Approach</h3><p>Each project is tailored to suit the unique needs of our clients, ensuring personalized service and a final result that is both functional and aesthetically pleasing. We go beyond just meeting expectations; we aim to exceed them by delivering designs that inspire and endure.</p></article>
      </div>
      <div class="wide-image reveal"><img src="assets/images/img_07.jpeg" alt="Bamboo lighting installation"><span>Natural material. Considered design.</span></div>
    </section>

    <section class="projects section" id="work">
      <div class="section-tag reveal">05 / OUR FEW PROJECTS</div>
      <div class="projects-head reveal"><h2>Made by hand.<br><em>Made to last.</em></h2><p>A selection of bamboo structures, furniture, lighting and crafted objects from the Earth Gramineae portfolio.</p></div>
      <?php if($projects): $feature=$projects[0]; ?>
      <div class="project-feature reveal"><img src="<?=eh($feature['image'])?>" alt="<?=eh($feature['title'])?>"><div><p class="project-number">01</p><h3><?=eh($feature['title'])?></h3><p><?=eh($feature['description'])?></p></div></div>
      <div class="gallery" aria-label="Project gallery">
      <?php foreach(array_slice($projects,1) as $p): ?><button class="gallery-card <?=((int)$p['sort_order']%5===0?'tall':'')?>" data-title="<?=eh($p['title'])?>"><img src="<?=eh($p['image'])?>" alt="<?=eh($p['title'])?>"><span><?=eh($p['title'])?></span></button><?php endforeach; ?>
      </div>
      <div class="project-details">
      <?php foreach(array_slice($projects,1) as $p): ?><article class="detail reveal"><span><?=str_pad((string)$p['sort_order'],2,'0',STR_PAD_LEFT)?></span><h3><?=eh($p['title'])?></h3><p><?=eh($p['description'])?></p></article><?php endforeach; ?>
      </div>
      <?php else: ?><div class="project-feature reveal"><img src="assets/images/img_24.jpeg" alt="Earth Gramineae bamboo gazebo"><div><p class="project-number">01</p><h3>Gazebo</h3><p>Crafted from sustainably sourced bamboo, this gazebo blends natural elegance with modern eco-design.</p></div></div><?php endif; ?>
    </section>

    <section class="cta" id="contact">
      <div class="cta-inner reveal">
        <p class="eyebrow">06 / LET'S WORK TOGETHER</p>
        <h2>Have a space<br>in mind?</h2>
        <p>Tell us what you're imagining. We can talk through a structure, furniture piece, garden landscape, installation or bespoke bamboo idea.</p>
        <div class="contact-layout">
          <form id="contactForm" class="contact-form">
            <label>Your name<input id="name" required placeholder="Name"></label>
            <label>Project / service<input id="project" placeholder="What are you looking for?"></label>
            <label>Your message<textarea id="message" required rows="4" placeholder="Tell us a little about your idea..."></textarea></label>
            <div class="form-actions"><button class="btn btn-dark" type="submit">Send via WhatsApp <span>↗</span></button><button class="btn btn-outline" type="button" id="emailBtn">Send via Email</button></div>
          </form>
          <div class="contact-direct">
            <p class="contact-label">DIRECT</p>
            <a href="tel:<?=eh($wa)?>" class="contact-big"><?=eh($phone)?></a>
            <a href="mailto:<?=eh($email)?>"><?=eh($email)?></a>
            <a href="https://www.instagram.com/earth.gramineae/" target="_blank" rel="noopener">@earth.gramineae</a>
            <div class="quick-actions"><a href="tel:<?=eh($wa)?>">Call</a><a href="https://wa.me/<?=eh($wa)?>" target="_blank" rel="noopener">WhatsApp</a><a href="mailto:<?=eh($email)?>">Email</a></div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer><div><strong>Earth Gramineae</strong><span>Future from the past.</span></div><a href="#top">Back to top ↑</a><small>© <span id="year"></span> Earth Gramineae. Crafted around bamboo, culture and conscious design.</small></footer>
  <div class="lightbox" id="lightbox" aria-hidden="true"><button class="lightbox-close" aria-label="Close">×</button><img id="lightboxImg" src="" alt=""><p id="lightboxTitle"></p></div>
  <script src="script.js"></script>
</body>
</html>
