<?php
declare(strict_types=1);
function eg_table(PDO $pdo,string $table):bool{ $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$q->execute([$table]);return (bool)$q->fetchColumn(); }
function eg_column(PDO $pdo,string $table,string $column):bool{ if(!eg_table($pdo,$table)) return false; $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");$q->execute([$table,$column]);return (bool)$q->fetchColumn(); }
function eg_add(PDO $pdo,string $table,string $column,string $definition):void{ if(!eg_column($pdo,$table,$column)) $pdo->exec("ALTER TABLE `".str_replace('`','',$table)."` ADD COLUMN `".str_replace('`','',$column)."` $definition"); }
function eg_migrate(PDO $pdo):void{
 $tables=[
 "CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL DEFAULT 'Administrator',email VARCHAR(190) NOT NULL,password_hash VARCHAR(255) NOT NULL,role VARCHAR(30) NOT NULL DEFAULT 'admin',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS settings(setting_key VARCHAR(120) PRIMARY KEY,setting_value LONGTEXT NULL) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS pages(id INT AUTO_INCREMENT PRIMARY KEY,slug VARCHAR(120) NOT NULL,title VARCHAR(190),content_json LONGTEXT NULL,custom_css LONGTEXT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS projects(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(190),category VARCHAR(120),description TEXT,image VARCHAR(255),sort_order INT DEFAULT 0,status TINYINT DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS invoices(id INT AUTO_INCREMENT PRIMARY KEY,serial_no VARCHAR(80),invoice_date DATE,due_date VARCHAR(80),customer_name VARCHAR(190),customer_address TEXT,customer_phone VARCHAR(80),customer_email VARCHAR(190),bank_details LONGTEXT,total DECIMAL(14,2) DEFAULT 0,paid DECIMAL(14,2) DEFAULT 0,notes TEXT,signature_image VARCHAR(255),email_subject VARCHAR(255),email_message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS invoice_items(id INT AUTO_INCREMENT PRIMARY KEY,invoice_id INT NOT NULL,description TEXT,price DECIMAL(14,2) DEFAULT 0,qty DECIMAL(14,2) DEFAULT 1,amount DECIMAL(14,2) DEFAULT 0) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS letters(id INT AUTO_INCREMENT PRIMARY KEY,serial_no VARCHAR(80),letter_date DATE,recipient TEXT,subject VARCHAR(255),body LONGTEXT,closing VARCHAR(255),signatory VARCHAR(190),signature_image VARCHAR(255),email_to VARCHAR(190),email_subject VARCHAR(255),email_message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB",
 "CREATE TABLE IF NOT EXISTS email_logs(id INT AUTO_INCREMENT PRIMARY KEY,document_type VARCHAR(30),document_id INT,to_email VARCHAR(190),subject VARCHAR(255),status VARCHAR(30),error_message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB"
 ];
 foreach($tables as $sql)$pdo->exec($sql);
 $adds=[
 'admins'=>['name'=>"VARCHAR(120) NOT NULL DEFAULT 'Administrator'",'email'=>"VARCHAR(190) NOT NULL DEFAULT ''",'password_hash'=>"VARCHAR(255) NOT NULL DEFAULT ''",'role'=>"VARCHAR(30) NOT NULL DEFAULT 'admin'",'created_at'=>"TIMESTAMP DEFAULT CURRENT_TIMESTAMP"],
 'settings'=>['setting_value'=>'LONGTEXT NULL'],
 'pages'=>['slug'=>"VARCHAR(120) NULL",'title'=>'VARCHAR(190) NULL','content_json'=>'LONGTEXT NULL','custom_css'=>'LONGTEXT NULL','updated_at'=>'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'],
 'projects'=>['title'=>'VARCHAR(190) NULL','category'=>'VARCHAR(120) NULL','description'=>'TEXT NULL','image'=>'VARCHAR(255) NULL','sort_order'=>'INT DEFAULT 0','status'=>'TINYINT DEFAULT 1','created_at'=>'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'],
 'invoices'=>['serial_no'=>'VARCHAR(80) NULL','invoice_date'=>'DATE NULL','due_date'=>'VARCHAR(80) NULL','customer_name'=>'VARCHAR(190) NULL','customer_address'=>'TEXT NULL','customer_phone'=>'VARCHAR(80) NULL','customer_email'=>'VARCHAR(190) NULL','bank_details'=>'LONGTEXT NULL','total'=>'DECIMAL(14,2) DEFAULT 0','paid'=>'DECIMAL(14,2) DEFAULT 0','notes'=>'TEXT NULL','signature_image'=>'VARCHAR(255) NULL','email_subject'=>'VARCHAR(255) NULL','email_message'=>'TEXT NULL','created_at'=>'TIMESTAMP DEFAULT CURRENT_TIMESTAMP','updated_at'=>'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'],
 'invoice_items'=>['invoice_id'=>'INT NOT NULL DEFAULT 0','description'=>'TEXT NULL','price'=>'DECIMAL(14,2) DEFAULT 0','qty'=>'DECIMAL(14,2) DEFAULT 1','amount'=>'DECIMAL(14,2) DEFAULT 0'],
 'letters'=>['serial_no'=>'VARCHAR(80) NULL','letter_date'=>'DATE NULL','recipient'=>'TEXT NULL','subject'=>'VARCHAR(255) NULL','body'=>'LONGTEXT NULL','closing'=>'VARCHAR(255) NULL','signatory'=>'VARCHAR(190) NULL','signature_image'=>'VARCHAR(255) NULL','email_to'=>'VARCHAR(190) NULL','email_subject'=>'VARCHAR(255) NULL','email_message'=>'TEXT NULL','created_at'=>'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'],
 'email_logs'=>['document_type'=>'VARCHAR(30) NULL','document_id'=>'INT NULL','to_email'=>'VARCHAR(190) NULL','subject'=>'VARCHAR(255) NULL','status'=>'VARCHAR(30) NULL','error_message'=>'TEXT NULL','created_at'=>'TIMESTAMP DEFAULT CURRENT_TIMESTAMP']];
 foreach($adds as $table=>$cols) foreach($cols as $c=>$d) eg_add($pdo,$table,$c,$d);
 // Avoid ON DUPLICATE KEY on legacy schemas that may not have unique indexes.
 $defaults=[
 'home'=>['Home',['hero_title'=>'Future<br><em>from the past.</em>','hero_copy'=>'Bamboo-led architecture, furniture and eco-living spaces where cultural heritage meets contemporary design.','intro_display'=>'Building with a material that grows back.','intro_p1'=>'Established in 2019, Earth Gramineae is dedicated to crafting innovative, eco-conscious structures using bamboo—a fast-growing, renewable resource.','intro_p2'=>'Our mission is to deliver distinctive, sustainable products, carefully designed to meet modern aesthetic and environmental needs.','meta_title'=>'Earth Gramineae — Future From The Past','meta_description'=>'Eco-sustainable bamboo architecture, furniture, garden landscapes and eco-living spaces from Meghalaya.']],
 'theme'=>['Theme',['primary'=>'#172116','custom_css'=>'']],
 'invoice'=>['Invoice Studio',['title'=>'INVOICE','subtitle'=>'EARTH GRAMINEAE • BAMBOO & SUSTAINABLE WORKS','primary'=>'#20264a','paper_background'=>'#ffffff','header_background'=>'#f4f4f4','label_color'=>'#999999','footer_left'=>'Earth Gramineae · Est. 2019','footer_right'=>'Thank you for your business','custom_css'=>'']],
 'letterhead'=>['Letter Head',['primary'=>'#20264a','watermark_opacity'=>'0.08','footer_text'=>'Earth Gramineae · Future from the past.','custom_css'=>'']]
 ];
 foreach($defaults as $slug=>$v){$q=$pdo->prepare('SELECT id,content_json FROM pages WHERE slug=? LIMIT 1');$q->execute([$slug]);$r=$q->fetch();$json=json_encode($v[1],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if($r){$current=$r['content_json']??'';if(trim($current)===''){$u=$pdo->prepare('UPDATE pages SET title=?,content_json=?,custom_css=? WHERE id=?');$u->execute([$v[0],$json,'',$r['id']]);}}else{$i=$pdo->prepare('INSERT INTO pages(slug,title,content_json,custom_css) VALUES(?,?,?,?)');$i->execute([$slug,$v[0],$json,'']);}}
 // Seed the portfolio only when no projects exist. This preserves the exact supplied frontend gallery.
 $count=(int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
 if($count===0){
   $projects=[
    ['Gazebo','Architecture','Crafted from sustainably sourced bamboo, this gazebo by Earth Gramineae blends natural elegance with modern eco-design. It offers a serene, stylish outdoor space perfect for relaxation or social gatherings.','assets/images/img_24.jpeg',1],
    ['Bamboo Bed','Furniture','Earth Gramineae’s bamboo bed combines natural materials with modern craftsmanship to create a sustainable, eco-friendly sleeping solution. Built from durable, locally sourced bamboo, this bed offers both strength and elegance.','assets/images/img_25.jpeg',2],
    ['Chandelier','Lighting','Elegantly crafted from bamboo, this chandelier brings a touch of nature indoors. Its intricate design and warm ambient glow make it a distinctive statement piece.','assets/images/img_07.jpeg',3],
    ['Bamboo Tiki','Craft','This bamboo tiki brings tropical, rustic charm to a space, blending cultural artistry with sustainable materials.','assets/images/img_27.jpeg',4],
    ['Knife Case','Craft','A durable and eco-friendly bamboo knife case offering natural protection with rustic elegance.','assets/images/img_28.jpeg',5],
    ['Bamboo Shelf','Furniture','A minimalist yet sturdy bamboo storage solution that blends functionality with natural beauty.','assets/images/img_29.jpeg',6],
    ['Lariti Art & Culture Gate Entrance','Architecture','An impressive 18 to 25 feet tall bamboo gate entrance, crafted as a bold sustainable architectural statement.','assets/images/img_30.jpeg',7],
    ['Bamboo Coaster','Craft','Refined bamboo coasters combining smooth finishing, minimalist design and eco-friendly elegance.','assets/images/img_23.jpeg',8],
    ['Bamboo Art','Art','Framed bamboo artwork celebrating natural material, craft and Meghalaya-inspired design.','assets/images/img_20.jpeg',9],
    ['Bamboo Craft','Craft','A curated bamboo craft display highlighting handmade material culture and sustainable design.','assets/images/img_21.jpeg',10],
    ['Bamboo Lighting','Lighting','Warm bamboo lighting pieces that merge natural material with considered interior design.','assets/images/img_11.jpeg',11]
   ];
   $pi=$pdo->prepare("INSERT INTO projects(title,category,description,image,sort_order,status) VALUES(?,?,?,?,?,1)");
   foreach($projects as $p)$pi->execute($p);
 }

}
