<?php
return array (
  'db_host' => 'sql303.infinityfree.com',
  'db_name' => 'if0_42570270_eg',
  'db_user' => 'if0_42570270',
  'db_pass' => 'zEPhpnlJGEL',
  'base_url' => 'https://eg.free.je',
);
